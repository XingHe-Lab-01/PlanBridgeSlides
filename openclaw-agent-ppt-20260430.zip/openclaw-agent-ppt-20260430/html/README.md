# HTML Route

- Source: empty deck workspace
- Deck workspace: `E:\1.个人资料\广电\skills\openclaw-agent-ppt-20260430\html\src\openclaw-html-deck`
- Project-local assets: `E:\1.个人资料\广电\skills\openclaw-agent-ppt-20260430\html\assets`
- Branch slides plan copy: `E:\1.个人资料\广电\skills\openclaw-agent-ppt-20260430\html\slides_plan.md`
- HTML design notes: `E:\1.个人资料\广电\skills\openclaw-agent-ppt-20260430\html\html_design_plan.md`

Next:
1. Read html/slides_plan.md
2. Finalize theme / template / layout mapping in html/html_design_plan.md
3. Author the HTML deck in html/src/
4. Export standalone HTML into html/exports/
5. Verify it opens as a self-contained file, then copy it to output/
