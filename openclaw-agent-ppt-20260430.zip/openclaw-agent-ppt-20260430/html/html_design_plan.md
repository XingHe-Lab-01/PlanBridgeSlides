# HTML Design Plan

- chosen theme: `corporate-clean` as default, with runtime theme cycling across `corporate-clean`, `engineering-whiteprint`, and `minimal-white`.
- chosen starting template: runtime-compatible scratch deck. The visual slide bodies reuse the verified PPTX `svg_final/` pages as inline SVG so the HTML version matches the PPTX version exactly.
- slide-to-layout mapping: 30 inline SVG slides, one `.slide` per page, preserving the page sequence from `html/slides_plan.md`.
- runtime feature decisions: include `base.css`, `fonts.css`, `runtime.js`; support keyboard navigation, overview, quick notes drawer, and `S` presenter mode.
- notes strategy: reuse the already generated 30 per-slide speaker notes from the PPTX project, embedded in each slide's hidden `.notes` block.
- standalone export: run `export-standalone.py` against `html/src/openclaw-html-deck/index.html`, then copy the verified output to project `output/`.
