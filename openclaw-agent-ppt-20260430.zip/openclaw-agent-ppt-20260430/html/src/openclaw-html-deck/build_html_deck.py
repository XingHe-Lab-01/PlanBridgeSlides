from __future__ import annotations

from html import escape
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[2]
PLAN = PROJECT / "planning" / "slides_plan.md"
OUT = ROOT / "index.html"


def text_between(body: str, label: str) -> str:
    match = re.search(rf"^- {re.escape(label)}：(.+)$", body, flags=re.M)
    return match.group(1).strip() if match else ""


def strip_md(text: str) -> str:
    text = re.sub(r"`([^`]+)`", r"\1", text)
    text = re.sub(r"\*\*([^*]+)\*\*", r"\1", text)
    text = text.replace("<br>", " ").replace("<br/>", " ")
    return re.sub(r"\s+", " ", text).strip()


def short(text: str, limit: int = 46) -> str:
    text = strip_md(text)
    return text if len(text) <= limit else text[: limit - 3].rstrip() + "..."


def collect_core_items(body: str) -> list[str]:
    match = re.search(r"- 核心内容：\n(?P<items>.*?)(?:\n- 推荐布局意图：|\n- 候选页面原型：|\n- 讲稿提示：|\Z)", body, flags=re.S)
    if not match:
        return []
    items = []
    for line in match.group("items").splitlines():
        bullet = re.match(r"\s*-\s+(.+)", line)
        if bullet:
            items.append(strip_md(bullet.group(1)))
    return items


def parse_plan() -> list[dict[str, object]]:
    raw = PLAN.read_text(encoding="utf-8")
    parts = re.split(r"\n### 第\s*(\d+)\s*页\s*-\s*(.*?)\n", raw)
    slides: list[dict[str, object]] = []
    for idx in range(1, len(parts), 3):
        num = int(parts[idx])
        heading = strip_md(parts[idx + 1])
        body = parts[idx + 2]
        title = text_between(body, "标题") or re.sub(r"^[^：:]+[：:]\s*", "", heading)
        role = text_between(body, "页面角色")
        takeaway = text_between(body, "观众 takeaway")
        layout = text_between(body, "候选页面原型").strip("`")
        script_hint = text_between(body, "讲稿提示")
        slides.append(
            {
                "num": num,
                "heading": heading,
                "title": title,
                "role": role,
                "takeaway": takeaway,
                "layout": layout,
                "script_hint": script_hint,
                "items": collect_core_items(body),
            }
        )
    if len(slides) != 30:
        raise SystemExit(f"Expected 30 planned slides, found {len(slides)}")
    return slides


def note_files() -> dict[int, str]:
    project_notes = sorted((PROJECT / "pptx" / "projects").glob("*/notes/*.md"))
    notes: dict[int, str] = {}
    for path in project_notes:
        match = re.match(r"(\d+)_", path.name)
        if match:
            notes[int(match.group(1))] = path.read_text(encoding="utf-8")
    return notes


def note_to_html(markdown: str, fallback: str) -> str:
    content = markdown.strip() or fallback.strip()
    parts = []
    for line in [line.strip() for line in content.splitlines() if line.strip()]:
        if line.startswith("要点："):
            parts.append(f"<p><strong>要点：</strong>{escape(line[3:].strip())}</p>")
        elif line.startswith("时长："):
            parts.append(f"<p><strong>时长：</strong>{escape(line[3:].strip())}</p>")
        else:
            parts.append(f"<p>{escape(line)}</p>")
    return "\n".join(parts)


def footer(num: int) -> str:
    return f'<div class="kb-footer"><span>OpenClaw / Agent Blueprint</span><span>{num:02d} / 30</span></div>'


def notes(slide: dict[str, object], note_map: dict[int, str]) -> str:
    num = int(slide["num"])
    fallback = "\n".join(
        part for part in [str(slide.get("takeaway") or ""), str(slide.get("script_hint") or "")]
        if part
    )
    return f'<aside class="notes">\n{note_to_html(note_map.get(num, ""), fallback)}\n</aside>'


def card(title: str, body: str = "", klass: str = "") -> str:
    return (
        f'<div class="kb-card {klass}">'
        f"<h4>{escape(short(title, 28))}</h4>"
        f"{f'<p>{escape(short(body, 72))}</p>' if body else ''}"
        "</div>"
    )


def slide_shell(slide: dict[str, object], body: str, note_map: dict[int, str]) -> str:
    title = escape(str(slide["title"]))
    num = int(slide["num"])
    slide_class = "slide is-active" if num == 1 else "slide"
    return f'''<section class="{slide_class}" data-title="{title}">
  <div class="kb-grid-bg"></div>
  {body}
  {footer(num)}
  {notes(slide, note_map)}
</section>'''


def cover(slide: dict[str, object], note_map: dict[int, str]) -> str:
    body = f'''
  <div class="kb-cover-grid">
    <div>
      <div class="kb-kicker">OpenClaw / Agent Blueprint</div>
      <h1 class="kb-h1 kb-cover-title">{escape(str(slide["title"]))}</h1>
      <p class="kb-sub">{escape(str(slide["takeaway"]))}</p>
    </div>
    <div class="kb-insight"><span class="kk">KEY JUDGEMENT</span>不是追热点，而是用 OpenClaw 看清 Agent 的入口、执行、记忆、技能和治理。</div>
  </div>
  <div class="kb-pipeline kb-cover-pipeline">
    <div class="kb-step"><div class="kb-step-num">SIGNAL 01</div><div class="kb-step-title">现象级入口</div><div class="kb-step-body">“养龙虾”把 Agent 从极客话题推到企业讨论桌面。</div></div>
    <div class="kb-step hero"><div class="kb-step-num">CORE</div><div class="kb-step-title">行动型系统</div><div class="kb-step-body">聊天入口、工具执行、长期在线与技能生态形成闭环。</div></div>
    <div class="kb-step"><div class="kb-step-num">OUTCOME</div><div class="kb-step-title">硅基员工</div><div class="kb-step-body">企业真正要沉淀的是可治理、可审计、可复用的数字劳动力能力。</div></div>
  </div>'''
    return slide_shell(slide, body, note_map)


def agenda(slide: dict[str, object], note_map: dict[int, str]) -> str:
    items = list(slide["items"])[:7]
    cards = "\n".join(card(f"{i:02d}", item, "agenda-card") for i, item in enumerate(items, 1))
    body = f'''
  <div class="kb-kicker">Agenda</div>
  <h1 class="kb-h1">{escape(str(slide["title"]))}</h1>
  <p class="kb-sub">{escape(str(slide["takeaway"]))}</p>
  <div class="kb-grid-7">{cards}</div>'''
    return slide_shell(slide, body, note_map)


def timeline(slide: dict[str, object], note_map: dict[int, str]) -> str:
    items = list(slide["items"])[:4]
    steps = "\n".join(
        f'<div class="kb-step {"hero" if i == 2 else ""}"><div class="kb-step-num">NODE {i:02d}</div><div class="kb-step-title">{escape(short(item.split("：")[0], 16))}</div><div class="kb-step-body">{escape(short(item, 84))}</div></div>'
        for i, item in enumerate(items, 1)
    )
    body = f'''
  <div class="kb-kicker">Timeline / Roadmap</div>
  <h1 class="kb-h1">{escape(str(slide["title"]))}</h1>
  <p class="kb-sub">{escape(str(slide["takeaway"]))}</p>
  <div class="kb-pipeline">{steps}</div>'''
    return slide_shell(slide, body, note_map)


def pillars(slide: dict[str, object], note_map: dict[int, str]) -> str:
    items = list(slide["items"])[:6]
    cards = "\n".join(
        f'<div class="kb-card"><div class="kb-step-num">{i:02d}</div><h4>{escape(short(item.split("：")[0], 24))}</h4><p>{escape(short(item, 76))}</p></div>'
        for i, item in enumerate(items, 1)
    )
    body = f'''
  <div class="kb-kicker">{escape(str(slide["role"]) or "Framework")}</div>
  <h1 class="kb-h1">{escape(str(slide["title"]))}</h1>
  <p class="kb-sub">{escape(str(slide["takeaway"]))}</p>
  <div class="kb-grid-3">{cards}</div>'''
    return slide_shell(slide, body, note_map)


def architecture(slide: dict[str, object], note_map: dict[int, str]) -> str:
    items = list(slide["items"])[:8]
    cards = "\n".join(
        f'<div class="kb-layer {"hero" if i in (3, 5) else ""}"><span>{i:02d}</span><strong>{escape(short(item.split("：")[0], 22))}</strong><em>{escape(short(item, 70))}</em></div>'
        for i, item in enumerate(items, 1)
    )
    body = f'''
  <div class="kb-kicker">Architecture Map</div>
  <h1 class="kb-h1">{escape(str(slide["title"]))}</h1>
  <p class="kb-sub">{escape(str(slide["takeaway"]))}</p>
  <div class="kb-layer-grid">{cards}</div>'''
    return slide_shell(slide, body, note_map)


def comparison(slide: dict[str, object], note_map: dict[int, str]) -> str:
    items = list(slide["items"])[:8]
    midpoint = max(1, (len(items) + 1) // 2)
    left = "\n".join(f"<li>{escape(short(item, 62))}</li>" for item in items[:midpoint])
    right = "\n".join(f"<li>{escape(short(item, 62))}</li>" for item in items[midpoint:])
    body = f'''
  <div class="kb-kicker">Comparison / Positioning</div>
  <h1 class="kb-h1">{escape(str(slide["title"]))}</h1>
  <p class="kb-sub">{escape(str(slide["takeaway"]))}</p>
  <div class="kb-grid-2">
    <div class="kb-card"><div class="kb-kicker muted">维度 A</div><ul class="kb-list">{left}</ul></div>
    <div class="kb-card hero"><div class="kb-kicker">维度 B</div><ul class="kb-list">{right}</ul></div>
  </div>'''
    return slide_shell(slide, body, note_map)


def risk(slide: dict[str, object], note_map: dict[int, str]) -> str:
    items = list(slide["items"])[:6]
    rows = "\n".join(
        f'<div class="kb-risk-row"><span class="kb-risk-dot">{i}</span><strong>{escape(short(item.split("：")[0], 24))}</strong><p>{escape(short(item, 76))}</p></div>'
        for i, item in enumerate(items, 1)
    )
    body = f'''
  <div class="kb-kicker">Risk / Governance</div>
  <h1 class="kb-h1">{escape(str(slide["title"]))}</h1>
  <p class="kb-sub">{escape(str(slide["takeaway"]))}</p>
  <div class="kb-risk-board">{rows}</div>'''
    return slide_shell(slide, body, note_map)


def action(slide: dict[str, object], note_map: dict[int, str]) -> str:
    items = list(slide["items"])[:4]
    steps = "\n".join(
        f'<div class="kb-step {"hero" if i == 3 else ""}"><div class="kb-step-num">PHASE {i:02d}</div><div class="kb-step-title">{escape(short(item.split("：")[0], 18))}</div><div class="kb-step-body">{escape(short(item, 86))}</div></div>'
        for i, item in enumerate(items, 1)
    )
    body = f'''
  <div class="kb-kicker">Action Plan</div>
  <h1 class="kb-h1">{escape(str(slide["title"]))}</h1>
  <p class="kb-sub">{escape(str(slide["takeaway"]))}</p>
  <div class="kb-pipeline">{steps}</div>'''
    return slide_shell(slide, body, note_map)


def close(slide: dict[str, object], note_map: dict[int, str]) -> str:
    items = list(slide["items"])[:3]
    cards = "\n".join(card(item.split("：")[0], item) for item in items)
    body = f'''
  <div class="kb-close">
    <div class="kb-kicker">Close / Vision</div>
    <h1 class="kb-h1 kb-close-title">{escape(str(slide["title"]))}</h1>
    <p class="kb-sub">{escape(str(slide["takeaway"]))}</p>
    <div class="kb-grid-3">{cards}</div>
  </div>'''
    return slide_shell(slide, body, note_map)


def default_slide(slide: dict[str, object], note_map: dict[int, str]) -> str:
    items = list(slide["items"])[:5]
    bullets = "\n".join(f"<li>{escape(short(item, 74))}</li>" for item in items)
    body = f'''
  <div class="kb-content-split">
    <div>
      <div class="kb-kicker">{escape(str(slide["role"]) or "OpenClaw Briefing")}</div>
      <h1 class="kb-h1">{escape(str(slide["title"]))}</h1>
      <p class="kb-sub">{escape(str(slide["takeaway"]))}</p>
    </div>
    <div class="kb-card hero">
      <div class="kb-section-label">Key Points</div>
      <ul class="kb-list">{bullets}</ul>
    </div>
  </div>'''
    return slide_shell(slide, body, note_map)


def render_slide(slide: dict[str, object], note_map: dict[int, str]) -> str:
    num = int(slide["num"])
    title = str(slide["title"])
    layout = str(slide.get("layout") or "")
    if num == 1:
        return cover(slide, note_map)
    if num == 3:
        return agenda(slide, note_map)
    if "timeline" in layout or "时间线" in title:
        return timeline(slide, note_map)
    if any(word in title for word in ["风险", "安全", "治理", "盲目"]):
        return risk(slide, note_map)
    if any(word in title for word in ["行动", "路线", "阶段", "怎么吸收", "落地"]):
        return action(slide, note_map)
    if any(word in title for word in ["架构", "八层", "系统", "Runtime", "Skills", "闭环"]):
        return architecture(slide, note_map)
    if any(word in title for word in ["对比", "相比", "关系", "不是所有"]):
        return comparison(slide, note_map)
    if "three-pillar" in layout or "四大" in title:
        return pillars(slide, note_map)
    if num >= 29 or any(word in title for word in ["未来", "愿景", "革命"]):
        return close(slide, note_map)
    return default_slide(slide, note_map)


def main() -> None:
    slides = parse_plan()
    note_map = note_files()
    slide_html = "\n".join(render_slide(slide, note_map) for slide in slides)
    html = f'''<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>OpenClaw：从“养一只龙虾”到硅基员工革命</title>
  <link rel="stylesheet" href="../../assets/fonts.css">
  <link rel="stylesheet" href="../../assets/base.css">
  <link rel="stylesheet" id="theme-link" href="../../assets/themes/blueprint.css">
  <style>
    .tpl-knowledge-arch-blueprint {{
      --kb-bg: var(--bg);
      --kb-ink: var(--text-1);
      --kb-ink2: var(--text-2);
      --kb-ink3: var(--text-3);
      --kb-rust: var(--accent-3);
      --kb-line: var(--border-strong);
      --kb-card: color-mix(in srgb, var(--surface) 88%, transparent);
      --kb-soft: color-mix(in srgb, var(--surface-2) 82%, transparent);
      background: var(--kb-bg);
      color: var(--kb-ink);
      font-family: var(--font-sans);
    }}
    .tpl-knowledge-arch-blueprint .slide {{
      background: var(--kb-bg);
      color: var(--kb-ink);
      padding: 52px 70px 58px;
    }}
    .tpl-knowledge-arch-blueprint .kb-grid-bg {{
      position: absolute;
      inset: 0;
      pointer-events: none;
      opacity: .42;
      background-image:
        linear-gradient(color-mix(in srgb, var(--accent-2) 22%, transparent) 1px, transparent 1px),
        linear-gradient(90deg, color-mix(in srgb, var(--accent-2) 22%, transparent) 1px, transparent 1px);
      background-size: 48px 48px;
      mask-image: radial-gradient(ellipse at center, black 38%, transparent 86%);
    }}
    .kb-kicker {{
      font-family: var(--font-mono);
      font-size: 12px;
      font-weight: 800;
      letter-spacing: .24em;
      text-transform: uppercase;
      color: var(--kb-rust);
      margin-bottom: 10px;
    }}
    .kb-kicker.muted {{ color: var(--kb-ink3); }}
    .kb-h1 {{
      font-family: var(--font-display);
      font-size: 46px;
      font-weight: 850;
      line-height: 1.12;
      letter-spacing: 0;
      color: var(--kb-ink);
      margin: 0 0 14px;
      max-width: 1060px;
    }}
    .kb-cover-title {{ font-size: 68px; max-width: 820px; }}
    .kb-close-title {{ font-size: 64px; text-align: center; margin-left: auto; margin-right: auto; }}
    .kb-sub {{
      font-size: 20px;
      line-height: 1.55;
      color: var(--kb-ink2);
      max-width: 860px;
      margin: 0;
    }}
    .kb-cover-grid {{
      display: grid;
      grid-template-columns: 1fr 330px;
      gap: 44px;
      align-items: start;
      margin-bottom: 36px;
    }}
    .kb-insight {{
      background: var(--kb-rust);
      color: #fff;
      border: 1px solid color-mix(in srgb, var(--kb-rust) 78%, #fff);
      padding: 18px 20px;
      font-size: 15px;
      line-height: 1.55;
      font-weight: 750;
    }}
    .kb-insight .kk {{
      display: block;
      font-family: var(--font-mono);
      font-size: 10px;
      letter-spacing: .22em;
      opacity: .76;
      margin-bottom: 8px;
    }}
    .kb-section-label {{
      font-family: var(--font-mono);
      font-size: 11px;
      font-weight: 800;
      letter-spacing: .22em;
      color: var(--kb-ink3);
      text-transform: uppercase;
      margin-bottom: 14px;
    }}
    .kb-pipeline {{
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 16px;
      margin-top: 28px;
    }}
    .kb-cover-pipeline {{ grid-template-columns: repeat(3, minmax(0, 1fr)); }}
    .kb-step, .kb-card, .kb-layer, .kb-risk-row {{
      border: 2px solid var(--kb-line);
      background: var(--kb-card);
      backdrop-filter: blur(8px);
    }}
    .kb-step {{
      min-height: 168px;
      padding: 19px 18px;
      display: flex;
      flex-direction: column;
    }}
    .kb-step.hero, .kb-card.hero, .kb-layer.hero {{
      background: color-mix(in srgb, var(--kb-rust) 18%, var(--surface));
      border-color: var(--kb-rust);
    }}
    .kb-step-num {{
      font-family: var(--font-mono);
      font-size: 11px;
      font-weight: 800;
      letter-spacing: .18em;
      color: var(--kb-ink3);
      margin-bottom: 8px;
    }}
    .kb-step-title {{
      font-size: 22px;
      font-weight: 850;
      line-height: 1.22;
      margin-bottom: 8px;
      color: var(--kb-ink);
    }}
    .kb-step-body {{
      color: var(--kb-ink2);
      font-size: 13px;
      line-height: 1.58;
      margin-top: auto;
    }}
    .kb-card {{
      padding: 20px 22px;
      min-height: 128px;
    }}
    .kb-card h4 {{
      font-size: 21px;
      line-height: 1.28;
      margin: 0 0 8px;
      color: var(--kb-ink);
    }}
    .kb-card p {{
      margin: 0;
      color: var(--kb-ink2);
      font-size: 14px;
      line-height: 1.55;
    }}
    .kb-grid-2, .kb-grid-3, .kb-grid-7 {{
      display: grid;
      gap: 18px;
      margin-top: 26px;
    }}
    .kb-grid-2 {{ grid-template-columns: repeat(2, minmax(0, 1fr)); }}
    .kb-grid-3 {{ grid-template-columns: repeat(3, minmax(0, 1fr)); }}
    .kb-grid-7 {{ grid-template-columns: repeat(4, minmax(0, 1fr)); }}
    .agenda-card:nth-child(7) {{ grid-column: span 2; }}
    .kb-content-split {{
      display: grid;
      grid-template-columns: 1.03fr .97fr;
      gap: 44px;
      align-items: center;
    }}
    .kb-list {{
      margin: 0;
      padding-left: 18px;
      color: var(--kb-ink2);
      font-size: 16px;
      line-height: 1.68;
    }}
    .kb-list li + li {{ margin-top: 8px; }}
    .kb-layer-grid {{
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 14px;
      margin-top: 24px;
    }}
    .kb-layer {{
      min-height: 142px;
      padding: 17px 16px;
      display: flex;
      flex-direction: column;
      gap: 7px;
    }}
    .kb-layer span {{
      font-family: var(--font-mono);
      color: var(--kb-rust);
      font-weight: 900;
      font-size: 13px;
    }}
    .kb-layer strong {{
      font-size: 19px;
      line-height: 1.24;
      color: var(--kb-ink);
    }}
    .kb-layer em {{
      font-style: normal;
      color: var(--kb-ink2);
      font-size: 12px;
      line-height: 1.48;
    }}
    .kb-risk-board {{
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 14px 18px;
      margin-top: 24px;
    }}
    .kb-risk-row {{
      min-height: 102px;
      padding: 16px 18px 14px 56px;
      position: relative;
    }}
    .kb-risk-dot {{
      position: absolute;
      left: 16px;
      top: 16px;
      width: 28px;
      height: 28px;
      display: grid;
      place-items: center;
      border: 2px solid var(--kb-rust);
      color: var(--kb-rust);
      font-family: var(--font-mono);
      font-weight: 900;
      font-size: 13px;
    }}
    .kb-risk-row strong {{
      display: block;
      color: var(--kb-ink);
      font-size: 18px;
      margin-bottom: 4px;
    }}
    .kb-risk-row p {{
      margin: 0;
      color: var(--kb-ink2);
      font-size: 13px;
      line-height: 1.45;
    }}
    .kb-close {{
      margin: auto 0;
      text-align: center;
    }}
    .kb-close .kb-sub {{
      margin-left: auto;
      margin-right: auto;
      margin-bottom: 26px;
    }}
    .kb-footer {{
      position: absolute;
      left: 70px;
      right: 70px;
      bottom: 28px;
      display: flex;
      justify-content: space-between;
      color: var(--kb-ink3);
      font-family: var(--font-mono);
      font-size: 10px;
      letter-spacing: .16em;
      text-transform: uppercase;
      border-top: 1px solid var(--kb-line);
      padding-top: 12px;
    }}
  </style>
</head>
<body class="tpl-knowledge-arch-blueprint" data-themes="blueprint,engineering-whiteprint,corporate-clean,tokyo-night" data-theme-base="../../assets/themes/">
  <div class="deck" id="deck">
{slide_html}
  </div>
  <script src="../../assets/runtime.js"></script>
</body>
</html>
'''
    OUT.write_text(html, encoding="utf-8")
    print(f"Wrote {OUT} with {len(slides)} template slides")


if __name__ == "__main__":
    main()
