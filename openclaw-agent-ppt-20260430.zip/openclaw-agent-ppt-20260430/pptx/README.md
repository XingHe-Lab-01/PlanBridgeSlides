# PPTX Route

- ppt-master project: `E:\1.个人资料\广电\skills\openclaw-agent-ppt-20260430\pptx\projects\openclaw-agent-ppt-20260430-pptx_ppt169_20260430`
- ppt-master engine bundle: `C:\Users\Duanxy\.codex\skills\grgppt-v2\ppt-master`
- Branch slides plan copy: `E:\1.个人资料\广电\skills\openclaw-agent-ppt-20260430\pptx\slides_plan.md`
- Design spec template: `E:\1.个人资料\广电\skills\openclaw-agent-ppt-20260430\pptx\design_spec_template.md`
- Final design spec path after confirmations: `pptx/design_spec.md`

Notes:
- PPTX route is bundle-driven: executor, post-processing, icon library, and chart template library remain under the bundled `ppt-master/` engine.
- Unlike the HTML route, PPTX route does not require project-local asset-path rewriting.
- The project-local `templates/` directory inside the generated ppt-master project is reserved for selected/copied template files for that project, not for mirroring the whole engine template library.

Next:
1. Read pptx/slides_plan.md
2. Run ppt-master template/theme confirmation
3. Run the Eight Confirmations using slides_plan.md as the content basis
4. Translate slides_plan.md plus confirmed PPTX decisions into pptx/design_spec.md
5. Move or copy finalized design_spec.md into the ppt-master project root if needed
6. Continue with the ppt-master executor/export pipeline, then copy the final PPTX to output/
