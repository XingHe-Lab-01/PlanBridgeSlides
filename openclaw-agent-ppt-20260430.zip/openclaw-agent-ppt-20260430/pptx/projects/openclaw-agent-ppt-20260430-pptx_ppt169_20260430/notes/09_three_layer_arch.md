把八层抽象能力落到 OpenClaw，就是入口、运行时和技能生态三层。
要点：① Gateway 管入口 ② Runtime 管执行 ③ Skills 管可复用能力
时长：2 分钟