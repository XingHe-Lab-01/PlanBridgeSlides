from pathlib import Path
from xml.sax.saxutils import escape

PROJECT = Path(__file__).resolve().parent
SVG_DIR = PROJECT / "svg_output"
NOTES_DIR = PROJECT / "notes"

W, H = 1280, 720
FONT = "system-ui, Microsoft YaHei, Arial, sans-serif"

C = {
    "bg": "#FFFFFF",
    "panel": "#F4F6F8",
    "panel2": "#EEF2F6",
    "ink": "#1F2933",
    "body": "#23313F",
    "muted": "#5B6775",
    "tertiary": "#8A94A3",
    "line": "#D9E0E7",
    "red": "#D71920",
    "blue": "#2563A6",
    "green": "#2E7D32",
    "risk": "#C62828",
    "orange": "#D97904",
    "dark": "#121923",
}


def e(text):
    return escape(str(text), {"\"": "&quot;"})


def wrap_text(text, max_chars=24):
    text = str(text)
    if not text:
        return []
    lines = []
    current = ""
    for part in text.replace("，", "， ").replace("；", "； ").replace("。", "。 ").split():
        if len(current) + len(part) <= max_chars:
            current += part
        else:
            if current:
                lines.append(current)
            current = part
    if current:
        lines.append(current)
    final = []
    for line in lines:
        if len(line) <= max_chars:
            final.append(line)
        else:
            for i in range(0, len(line), max_chars):
                final.append(line[i:i + max_chars])
    return final


def text(x, y, content, size=18, fill=None, weight="400", anchor="start", max_chars=None, lh=None):
    fill = fill or C["body"]
    lines = content if isinstance(content, list) else wrap_text(content, max_chars) if max_chars else [content]
    lh = lh or int(size * 1.35)
    out = [f'<text x="{x}" y="{y}" font-family="{FONT}" font-size="{size}" font-weight="{weight}" fill="{fill}" text-anchor="{anchor}">']
    for i, line in enumerate(lines):
        dy = 0 if i == 0 else lh
        out.append(f'<tspan x="{x}" dy="{dy}">{e(line)}</tspan>')
    out.append("</text>")
    return "\n".join(out)


def rect(x, y, w, h, fill, stroke=None, sw=1, rx=8, extra=""):
    st = f' stroke="{stroke}" stroke-width="{sw}"' if stroke else ""
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}"{st} {extra}/>'


def icon(name, x, y, size=34, fill=None):
    fill = fill or C["blue"]
    return f'<use data-icon="chunk/{name}" x="{x}" y="{y}" width="{size}" height="{size}" fill="{fill}"/>'


def defs():
    return f"""
<defs>
  <filter id="softShadow" x="-20%" y="-20%" width="150%" height="150%">
    <feGaussianBlur in="SourceAlpha" stdDeviation="7"/>
    <feOffset dx="0" dy="4" result="offsetBlur"/>
    <feFlood flood-color="#000000" flood-opacity="0.12" result="shadowColor"/>
    <feComposite in="shadowColor" in2="offsetBlur" operator="in" result="shadow"/>
    <feMerge><feMergeNode in="shadow"/><feMergeNode in="SourceGraphic"/></feMerge>
  </filter>
  <linearGradient id="headerGrad" x1="0%" y1="0%" x2="100%" y2="0%">
    <stop offset="0%" stop-color="{C['ink']}"/>
    <stop offset="100%" stop-color="{C['red']}"/>
  </linearGradient>
  <linearGradient id="redBlueGrad" x1="0%" y1="0%" x2="100%" y2="100%">
    <stop offset="0%" stop-color="{C['red']}"/>
    <stop offset="100%" stop-color="{C['blue']}"/>
  </linearGradient>
  <linearGradient id="softPanelGrad" x1="0%" y1="0%" x2="100%" y2="100%">
    <stop offset="0%" stop-color="#FFFFFF"/>
    <stop offset="100%" stop-color="{C['panel']}"/>
  </linearGradient>
</defs>
"""


def svg(body):
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">\n{defs()}\n{body}\n</svg>\n'


def header(title, takeaway, n, source=False):
    parts = [
        rect(0, 0, W, H, C["bg"], rx=0),
        rect(0, 0, 12, H, C["red"], rx=0),
        text(56, 56, title, 32, C["ink"], "700", max_chars=31),
        rect(56, 82, 1168, 44, C["panel"], rx=8),
        text(76, 110, takeaway, 15, C["muted"], "500", max_chars=72),
        f'<line x1="56" y1="650" x2="1224" y2="650" stroke="{C["line"]}" stroke-width="1"/>',
        text(56, 684, "内部培训 | OpenClaw Agent Briefing", 11, C["tertiary"]),
        text(1224, 684, f"{n:02d}/30", 11, C["tertiary"], anchor="end"),
    ]
    if source:
        parts.append(text(760, 684, "注：外部传播数字和案例用于内部认知，正式发布前需核验", 11, C["tertiary"], anchor="end"))
    return "\n".join(parts)


def card(x, y, w, h, title, body=None, color=None, icon_name=None, k=None):
    color = color or C["blue"]
    out = [
        f'<g id="card-{e(title)[:12]}">',
        rect(x, y, w, h, "#FFFFFF", C["line"], 1, 8, 'filter="url(#softShadow)"'),
        rect(x, y, 6, h, color, rx=4),
    ]
    tx = x + 24
    if icon_name:
        out += [
            f'<circle cx="{x + 38}" cy="{y + 38}" r="22" fill="{color}" fill-opacity="0.10"/>',
            icon(icon_name, x + 23, y + 23, 30, color),
        ]
        tx = x + 74
    if k:
        out.append(text(x + w - 22, y + 42, k, 28, color, "800", anchor="end"))
    out.append(text(tx, y + 34, title, 17, C["ink"], "700", max_chars=18))
    if body:
        out.append(text(x + 24, y + 68, body, 13, C["muted"], "400", max_chars=max(12, int((w - 48) / 16)), lh=19))
    out.append("</g>")
    return "\n".join(out)


def placeholder(x, y, w, h, label):
    return "\n".join([
        rect(x, y, w, h, C["panel"], C["tertiary"], 1.5, 8, 'stroke-dasharray="8,5"'),
        f'<circle cx="{x + w/2}" cy="{y + h/2 - 24}" r="32" fill="{C["blue"]}" fill-opacity="0.10"/>',
        icon("eye", x + w/2 - 18, y + h/2 - 42, 36, C["blue"]),
        text(x + w/2, y + h/2 + 22, label, 15, C["muted"], "600", anchor="middle", max_chars=22),
    ])


def slide_cover():
    body = [
        rect(0, 0, W, H, C["dark"], rx=0),
        f'<path d="M0,0 H1280 V720 H0 Z" fill="url(#redBlueGrad)" fill-opacity="0.12"/>',
        f'<circle cx="1010" cy="250" r="160" fill="{C["red"]}" fill-opacity="0.12"/>',
        f'<circle cx="1070" cy="320" r="82" fill="{C["blue"]}" fill-opacity="0.16"/>',
        f'<path d="M865,410 C930,330 1015,322 1080,392 C1020,372 962,407 914,475 Z" fill="{C["red"]}" fill-opacity="0.80"/>',
        f'<path d="M1010,388 C1060,338 1138,348 1178,414 C1116,392 1078,428 1048,490 Z" fill="{C["red"]}" fill-opacity="0.62"/>',
        text(76, 150, "OpenClaw", 62, "#FFFFFF", "800"),
        text(76, 224, "从“养一只龙虾”到硅基员工革命", 42, "#FFFFFF", "700", max_chars=22),
        rect(76, 280, 860, 58, "#FFFFFF", rx=8, extra='fill-opacity="0.10"'),
        text(104, 316, "2026 年开源 AI Agent 现象级案例深度内部科普", 22, "#FFFFFF", "600"),
        text(76, 640, "内部培训 | 根据源 Markdown 整理 | 本演示制作流程由大模型工具辅助", 15, "#D7DEE7"),
        text(1204, 640, "2026.04", 15, "#D7DEE7", anchor="end"),
    ]
    return svg("\n".join(body))


def slide_hook():
    body = [header("一个开源项目，为什么能让三个圈层同时关注", "OpenClaw 的出圈说明 Agent 已经从极客工具进入大众和企业讨论范围。", 2, True)]
    body.append(placeholder(68, 158, 500, 360, "现象截图占位：排队、热搜、社媒传播"))
    items = [("技术圈", "看到真实环境执行能力", "code", C["blue"]),
             ("产业圈", "看到 Agent OS / 数字员工入口", "toolbox", C["red"]),
             ("安全圈", "开始讨论权限、暴露和审计", "shield-check", C["green"])]
    for i, it in enumerate(items):
        body.append(card(610, 158 + i * 124, 560, 96, it[0], it[1], it[3], it[2]))
    body.append(rect(610, 540, 560, 70, C["ink"], rx=8))
    body.append(text(638, 583, "关键判断：AI 正从“会说”进入“会做”。", 24, "#FFFFFF", "700"))
    return svg("\n".join(body))


def slide_agenda():
    body = [header("45 分钟后，我们要回答两个问题", "它到底新在哪里？我们该如何吸收，而不是盲目跟风？", 3)]
    items = ["OpenClaw 是什么", "技术本质", "生态关系", "真实玩法", "风险与正确使用", "公司行动路线", "硅基员工愿景"]
    icons = ["robot", "code", "git-branch", "toolbox", "shield-check", "calendar", "users"]
    for i, item in enumerate(items):
        col = i % 2
        row = i // 2
        x = 92 + col * 560
        y = 158 + row * 118
        body.append(card(x, y, 500, 84, f"{i+1}. {item}", "从现象进入判断，再落到公司行动。", [C["red"], C["blue"], C["green"], C["orange"]][i % 4], icons[i]))
    return svg("\n".join(body))


def slide_compare(n, title, takeaway, left_title, left_items, right_title, right_items, left_color=None, right_color=None):
    left_color = left_color or C["muted"]
    right_color = right_color or C["red"]
    body = [header(title, takeaway, n)]
    body.append(rect(70, 158, 535, 420, "#FFFFFF", C["line"], 1, 8, 'filter="url(#softShadow)"'))
    body.append(rect(675, 158, 535, 420, "#FFFFFF", C["line"], 1, 8, 'filter="url(#softShadow)"'))
    body.append(rect(70, 158, 535, 56, left_color, rx=8))
    body.append(rect(675, 158, 535, 56, right_color, rx=8))
    body.append(text(338, 194, left_title, 24, "#FFFFFF", "700", anchor="middle"))
    body.append(text(943, 194, right_title, 24, "#FFFFFF", "700", anchor="middle"))
    for i, item in enumerate(left_items):
        body.append(text(106, 256 + i * 66, f"• {item}", 18, C["body"], "500", max_chars=25))
    for i, item in enumerate(right_items):
        body.append(text(711, 256 + i * 66, f"• {item}", 18, C["body"], "500", max_chars=25))
    return svg("\n".join(body))


def slide_timeline():
    body = [header("从个人助手到现象级 Agent 入口", "OpenClaw 的价值不在单点功能，而在于把 Agent 形态具体化了。", 5, True)]
    nodes = [("原型出现", "Clawdbot / Moltbot / OpenClaw", C["blue"]),
             ("社区扩散", "开源、自托管、个人助手理念", C["green"]),
             ("中国爆发", "云部署、社媒传播、硬件玩法", C["red"]),
             ("产业与安全并行", "企业想象和治理担忧同步出现", C["orange"])]
    y = 352
    body.append(f'<line x1="135" y1="{y}" x2="1145" y2="{y}" stroke="{C["line"]}" stroke-width="6" stroke-linecap="round"/>')
    for i, (t, d, col) in enumerate(nodes):
        x = 150 + i * 330
        body.append(f'<circle cx="{x}" cy="{y}" r="24" fill="{col}" stroke="#FFFFFF" stroke-width="4"/>')
        body.append(text(x, y + 7, str(i + 1), 18, "#FFFFFF", "800", anchor="middle"))
        cy = 188 if i % 2 == 0 else 430
        body.append(card(x - 130, cy, 260, 105, t, d, col, "calendar"))
        body.append(f'<line x1="{x}" y1="{y + (-24 if i % 2 else 24)}" x2="{x}" y2="{cy + (105 if i % 2 == 0 else 0)}" stroke="{col}" stroke-width="2" stroke-dasharray="6,4"/>')
    body.append(text(640, 612, "从“个人可控助手”到“公众可感知的 Agent 入口”，传播速度本身就是市场信号。", 22, C["ink"], "700", anchor="middle", max_chars=40))
    return svg("\n".join(body))


def slide_grid(n, title, takeaway, items, cols=3):
    body = [header(title, takeaway, n)]
    w = (1120 - (cols - 1) * 24) / cols
    h = 132 if len(items) > 4 else 155
    for i, item in enumerate(items):
        row = i // cols
        col = i % cols
        x = 80 + col * (w + 24)
        y = 164 + row * (h + 28)
        body.append(card(x, y, w, h, item["title"], item["body"], item.get("color"), item.get("icon"), item.get("k")))
    return svg("\n".join(body))


def slide_process(n, title, takeaway, steps, footer=None):
    body = [header(title, takeaway, n)]
    y = 300
    start_x = 92
    gap = 26
    wbox = (1096 - gap * (len(steps) - 1)) / len(steps)
    for i, s in enumerate(steps):
        x = start_x + i * (wbox + gap)
        col = s.get("color", [C["blue"], C["red"], C["green"], C["orange"]][i % 4])
        body.append(rect(x, y, wbox, 150, "#FFFFFF", C["line"], 1, 8, 'filter="url(#softShadow)"'))
        body.append(f'<circle cx="{x + wbox/2}" cy="{y - 34}" r="30" fill="{col}"/>')
        body.append(text(x + wbox/2, y - 27, f"{i+1}", 20, "#FFFFFF", "800", anchor="middle"))
        body.append(text(x + 20, y + 40, s["title"], 18, C["ink"], "700", max_chars=10))
        body.append(text(x + 20, y + 76, s["body"], 13, C["muted"], max_chars=12, lh=18))
        if i < len(steps) - 1:
            ax = x + wbox + 8
            body.append(f'<line x1="{ax}" y1="{y + 75}" x2="{ax + gap - 16}" y2="{y + 75}" stroke="{C["line"]}" stroke-width="2"/>')
            body.append(f'<polygon points="{ax + gap - 16},{y + 75} {ax + gap - 28},{y + 68} {ax + gap - 28},{y + 82}" fill="{C["line"]}"/>')
    if footer:
        body.append(rect(116, 540, 1048, 64, C["panel"], rx=8))
        body.append(text(640, 580, footer, 20, C["ink"], "700", anchor="middle", max_chars=42))
    return svg("\n".join(body))


def slide_arch_stack():
    body = [header("从外面看是“龙虾”，从里面看是八层系统", "OpenClaw 的价值在于把多层能力打通，而不是发明单一模块。", 8)]
    layers = [
        ("Eval & Observability", "完成率、成本、回放、定位、复现", C["muted"]),
        ("Safety & Governance", "人审、审计、权限、敏感信息策略", C["risk"]),
        ("Memory", "短期任务态与长期规则/环境记忆", C["green"]),
        ("Context Engineering", "对话、事实、工具日志、文档片段", C["blue"]),
        ("Connector Hub", "文档、工单、DB、OA、IM、CRM", C["orange"]),
        ("Tool Runtime", "注册、校验、重试、超时、沙箱", C["red"]),
        ("Planner", "任务拆解、子目标排序、并行策略", "#6B7280"),
        ("Orchestrator", "状态机、分支、回退、长任务", C["ink"]),
    ]
    for i, (name, desc, col) in enumerate(layers):
        y = 160 + i * 56
        body.append(rect(150, y, 980, 44, "#FFFFFF", C["line"], 1, 8, 'filter="url(#softShadow)"'))
        body.append(rect(150, y, 10, 44, col, rx=4))
        body.append(text(188, y + 28, name, 18, C["ink"], "800"))
        body.append(text(520, y + 28, desc, 16, C["muted"], "500", max_chars=36))
    body.append(text(640, 628, "企业落地时，治理、观测和权限往往比模型本身更决定成败。", 20, C["red"], "700", anchor="middle", max_chars=42))
    return svg("\n".join(body))


def slide_arch_three():
    body = [header("Gateway、Agent Runtime、Skills 组成行动型 Agent 框架", "OpenClaw 把入口、运行时和技能生态连成一个闭环。", 9)]
    layers = [("Gateway", "消息中枢、通道适配、会话、Cron、心跳", "cloud", C["blue"]),
              ("Agent Runtime", "任意 LLM、规划/反思循环、本地 Markdown 记忆", "robot", C["red"]),
              ("Skills", "社区插件、脚本、可复用能力、热插拔", "toolbox", C["green"])]
    for i, (name, desc, ic, col) in enumerate(layers):
        y = 168 + i * 128
        body.append(card(170, y, 940, 94, name, desc, col, ic, f"L{i+1}"))
    body.append(rect(170, 560, 940, 64, C["ink"], rx=8))
    body.append(text(640, 599, "LLM + 电脑 + 工具箱 + 权限 + 长期在线 = 数字劳动力雏形", 22, "#FFFFFF", "700", anchor="middle"))
    return svg("\n".join(body))


def slide_table(n, title, takeaway, headers, rows, highlight_col=None, source=False):
    body = [header(title, takeaway, n, source)]
    x0, y0 = 60, 156
    table_w, table_h = 1160, 438
    cols = len(headers)
    col_w = table_w / cols
    row_h = table_h / (len(rows) + 1)
    body.append(rect(x0, y0, table_w, row_h, C["ink"], rx=8))
    for c, h in enumerate(headers):
        body.append(text(x0 + c * col_w + 16, y0 + 33, h, 14, "#FFFFFF", "700", max_chars=int(col_w/15)))
    for r, row in enumerate(rows):
        y = y0 + row_h * (r + 1)
        fill = C["panel"] if r % 2 == 0 else "#FFFFFF"
        body.append(rect(x0, y, table_w, row_h, fill, C["line"], 1, 0))
        if highlight_col is not None:
            body.append(rect(x0 + highlight_col * col_w, y, col_w, row_h, C["red"], rx=0, extra='fill-opacity="0.06"'))
        for c, cell in enumerate(row):
            color = C["red"] if c == highlight_col else C["body"]
            body.append(text(x0 + c * col_w + 14, y + 26, cell, 12, color, "600" if c == 0 else "400", max_chars=max(8, int((col_w-26)/13)), lh=16))
    return svg("\n".join(body))


def slide_hub(n, title, takeaway, center, nodes):
    body = [header(title, takeaway, n)]
    cx, cy = 640, 370
    body.append(f'<circle cx="{cx}" cy="{cy}" r="82" fill="url(#redBlueGrad)" filter="url(#softShadow)"/>')
    body.append(text(cx, cy - 4, center[0], 24, "#FFFFFF", "800", anchor="middle"))
    body.append(text(cx, cy + 25, center[1], 15, "#FFFFFF", "600", anchor="middle"))
    positions = [(640,160),(955,230),(970,500),(640,585),(310,500),(325,230)]
    for i, node in enumerate(nodes):
        x, y = positions[i]
        col = node.get("color", [C["blue"], C["red"], C["green"], C["orange"], C["muted"], C["risk"]][i % 6])
        body.append(f'<line x1="{cx}" y1="{cy}" x2="{x}" y2="{y}" stroke="{col}" stroke-width="2" stroke-opacity="0.30"/>')
        body.append(card(x - 110, y - 44, 220, 88, node["title"], node["body"], col, node.get("icon")))
    return svg("\n".join(body))


def slide_case_image(n, title, takeaway, label, bullets, icon_name="robot"):
    body = [header(title, takeaway, n, True)]
    body.append(placeholder(70, 170, 500, 340, label))
    for i, b in enumerate(bullets):
        body.append(card(620, 170 + i * 102, 530, 82, b[0], b[1], b[2], icon_name))
    return svg("\n".join(body))


def slide_quote(n, title, takeaway, quote, bullets):
    body = [header(title, takeaway, n)]
    body.append(rect(96, 174, 1088, 190, C["ink"], rx=10, extra='filter="url(#softShadow)"'))
    body.append(text(640, 255, quote, 32, "#FFFFFF", "800", anchor="middle", max_chars=24, lh=45))
    for i, b in enumerate(bullets):
        body.append(card(118 + i * 360, 420, 326, 120, b[0], b[1], [C["red"], C["blue"], C["green"]][i % 3], b[2]))
    return svg("\n".join(body))


def slide_roadmap():
    body = [header("短期看清楚，中期补能力，长期沉淀体系", "公司可以按 0-3 个月、3-6 个月、6-12 个月分阶段推进。", 25)]
    stages = [("短期", "0-3 个月", "看清楚、拆明白", "调研路线；拆解入口、记忆、执行、调度、Skills、治理；形成 1-2 个低风险 PoC。", C["blue"]),
              ("中期", "3-6 个月", "补能力、做验证", "补齐记忆、技能资产化、任务调度、可观测与审计；开展内部试点。", C["red"]),
              ("长期", "6-12 个月", "沉淀体系、形成方法论", "结合知识中台、内部系统和业务流程，形成行业化 Agent 技术路线。", C["green"])]
    for i, (name, time, goal, work, col) in enumerate(stages):
        x = 120 + i * 370
        body.append(rect(x, 180, 320, 360, "#FFFFFF", C["line"], 1, 8, 'filter="url(#softShadow)"'))
        body.append(rect(x, 180, 320, 64, col, rx=8))
        body.append(text(x + 24, 220, f"{name} | {time}", 22, "#FFFFFF", "800"))
        body.append(text(x + 24, 290, goal, 22, col, "800", max_chars=12))
        body.append(text(x + 24, 340, work, 16, C["body"], max_chars=20, lh=24))
    body.append(text(640, 615, "核心产出：调研报告、能力图谱、试点原型、治理方法论、行业场景能力包。", 19, C["ink"], "700", anchor="middle", max_chars=46))
    return svg("\n".join(body))


def slide_columns(n, title, takeaway, cols):
    body = [header(title, takeaway, n)]
    for i, c in enumerate(cols):
        x = 86 + i * 390
        body.append(rect(x, 170, 340, 388, "#FFFFFF", C["line"], 1, 8, 'filter="url(#softShadow)"'))
        body.append(rect(x, 170, 340, 58, c["color"], rx=8))
        body.append(text(x + 24, 207, c["title"], 20, "#FFFFFF", "800"))
        for j, p in enumerate(c["items"]):
            body.append(text(x + 26, 270 + j * 78, f"{j+1}. {p}", 16, C["body"], "500", max_chars=18, lh=22))
    return svg("\n".join(body))


def slide_stairs():
    body = [header("真正的硅基员工雏形，出现在流程代理和多代理协同阶段", "问答助手只是起点，流程执行和多代理协作才是关键跃迁。", 28)]
    stages = [("问答助手", "只会回答", C["muted"]), ("工具调用", "查系统、调接口", C["blue"]), ("流程代理", "持续推进任务", C["red"]), ("多代理协同", "主管代理 + 专业代理", C["green"])]
    for i, (t, d, col) in enumerate(stages):
        x = 120 + i * 270
        y = 470 - i * 70
        body.append(f'<polygon points="{x},{y} {x+190},{y-50} {x+310},{y+2} {x+120},{y+55}" fill="{col}" fill-opacity="0.90" filter="url(#softShadow)"/>')
        body.append(text(x + 155, y + 5, str(i+1), 28, "#FFFFFF", "900", anchor="middle"))
        body.append(text(x + 155, y + 98, t, 20, C["ink"], "800", anchor="middle"))
        body.append(text(x + 155, y + 124, d, 14, C["muted"], "500", anchor="middle", max_chars=14))
    body.append(text(640, 628, "公司当前更应从工具调用和流程代理阶段切入，逐步走向可治理的多代理协同。", 20, C["red"], "700", anchor="middle", max_chars=45))
    return svg("\n".join(body))


def slide_close():
    body = [
        rect(0, 0, W, H, C["dark"], rx=0),
        f'<path d="M0,0 H1280 V720 H0 Z" fill="url(#redBlueGrad)" fill-opacity="0.14"/>',
        text(80, 130, "OpenClaw 只是开始", 50, "#FFFFFF", "800"),
        text(80, 196, "真正变化的是人机协作方式", 44, "#FFFFFF", "800", max_chars=18),
        rect(80, 270, 1060, 210, "#FFFFFF", rx=10, extra='fill-opacity="0.08"'),
        text(112, 326, "大模型正在从“会回答”走向“会执行”，软件正在从“被人操作”走向“可被委托”。", 26, "#FFFFFF", "700", max_chars=32, lh=40),
        text(112, 424, "未来值得关注的，不是谁先装一个最热工具，而是谁先构建可信、可控、可落地的硅基员工体系。", 24, "#FFFFFF", "600", max_chars=36, lh=38),
        text(80, 640, "谢谢", 30, "#FFFFFF", "800"),
        text(1204, 640, "30/30", 13, "#D7DEE7", anchor="end"),
    ]
    return svg("\n".join(body))


def build_pages():
    pages = []
    pages.append(("01_cover", slide_cover(), "开场先点明：今天不是追一个开源热点，而是借 OpenClaw 看清 Agent 技术和企业落地路线。\n要点：① OpenClaw 是公众化信号 ② 主题聚焦硅基员工 ③ 这份材料也由 AI 辅助完成\n时长：1 分钟"))
    pages.append(("02_opening_hook", slide_hook(), "OpenClaw 的特殊之处在于，它同时进入了技术、产业和安全三个讨论场。\n要点：① 技术圈看执行能力 ② 产业圈看新入口 ③ 安全圈看治理风险\n时长：1.5 分钟"))
    pages.append(("03_agenda", slide_agenda(), "这次分享围绕两个问题展开：它新在哪里，以及我们该如何吸收。\n要点：① 先讲现象和定义 ② 再讲技术和生态 ③ 最后落到风险与行动\n时长：1 分钟"))
    pages.append(("04_what_is_openclaw", slide_compare(4, "它不是聊天机器人，而是“Agent 外壳 + 执行系统”", "用户不是在和模型聊天，而是在给可行动的数字代理下任务。", "传统聊天机器人", ["围绕对话窗口回答问题", "主要输出文字和建议", "动作需要人类手动执行", "更适合知识问答和创作"], "OpenClaw 式 Agent", ["接收任务后可调用工具", "可操作浏览器、文件、Shell", "可以长期在线和主动唤醒", "更接近数字执行体"], C["muted"], C["red"]), "核心结论先讲清楚：OpenClaw 不是模型本身，而是给模型装上执行环境。\n要点：① 不等于 ChatGPT ② 入口是聊天 ③ 输出是行动\n时长：2 分钟"))
    pages.append(("05_timeline", slide_timeline(), "这页强调从个人助手到公共符号的转变，而不是背日期。\n要点：① 原型出现 ② 社区扩散 ③ 中国爆发 ④ 产业与安全并行\n时长：1.5 分钟"))
    pages.append(("06_china_breakout", slide_grid(6, "它踩中了中国用户最熟悉的三类入口", "OpenClaw 火起来，是因为它把 Agent 变成了可感知、可部署、可传播的体验。", [
        {"title": "聊天入口", "body": "通过熟悉的 IM 下命令，降低非技术用户理解成本。", "icon": "comment", "color": C["blue"]},
        {"title": "云端入口", "body": "云厂商的一键部署强化了“马上能用”的想象。", "icon": "cloud", "color": C["red"]},
        {"title": "设备入口", "body": "桌面、浏览器和硬件联动让“会执行”更直观。", "icon": "toolbox", "color": C["green"]},
        {"title": "安全入口", "body": "配置、鉴权、公网暴露开始进入企业安全视野。", "icon": "shield-check", "color": C["orange"]},
    ], cols=4), "国内传播不是偶然，它命中了聊天、云端、设备和安全四个入口。\n要点：① 体验直观 ② 部署门槛降低 ③ 治理同步上桌\n时长：2 分钟"))
    pages.append(("07_workflow_delegation", slide_process(7, "真正改变的不是聊天，而是工作流代理化", "Agent 的核心价值从“回答效率”转向“任务完成效率”。", [
        {"title": "过去", "body": "人来调用软件，AI 主要提升回答效率。", "color": C["muted"]},
        {"title": "现在", "body": "模型理解意图，并把任务拆成可执行步骤。", "color": C["blue"]},
        {"title": "未来", "body": "代理调用软件，围绕意图重组流程。", "color": C["red"]},
        {"title": "关键", "body": "模型理解 + 工具执行 + 反馈纠偏。", "color": C["green"]},
    ], "真正的变化，是软件从“被操作”变成“可委托”。"), "这页是全 deck 的中心判断，需要讲慢一点。\n要点：① 回答效率不是终点 ② 任务完成效率才是 Agent 价值 ③ 工作流开始围绕意图设计\n时长：2 分钟"))
    pages.append(("08_eight_layers", slide_arch_stack(), "从工程视角看，Agent 不是单层能力，而是一组持续协作的系统能力。\n要点：① 八层能力缺一不可 ② 治理和可观测很关键 ③ 企业落地不能只看 demo\n时长：3 分钟"))
    pages.append(("09_three_layer_arch", slide_arch_three(), "把八层抽象能力落到 OpenClaw，就是入口、运行时和技能生态三层。\n要点：① Gateway 管入口 ② Runtime 管执行 ③ Skills 管可复用能力\n时长：2 分钟"))
    pages.append(("10_new_vs_old", slide_table(10, "从实验性 Agent，到可持续运行的数字劳动力", "OpenClaw 的新意在于聊天入口、真实执行、持久记忆、主动调度和技能生态的组合。", ["维度", "去年常见 Agent", "OpenClaw 式 Agent", "创新意义"], [
        ["交互入口", "CLI / Web UI", "聊天 App 原生", "非技术人员也能理解"],
        ["执行能力", "API 调用为主", "OS、Shell、文件、浏览器", "从规划升级到动手"],
        ["记忆系统", "短期上下文 / RAG", "混合持久记忆", "长期状态可维护"],
        ["主动性", "一次性任务", "Heartbeat / Cron / 多会话", "更接近长期在线代理"],
        ["扩展方式", "开发者写代码", "Skills 生态", "能力资产化"],
        ["部署使用", "门槛较高", "更低上手门槛", "从 demo 走向日常使用"],
    ], highlight_col=2), "这页要克制：OpenClaw 更完整，但不等于已经企业级成熟。\n要点：① 入口更自然 ② 执行更真实 ③ 闭环更完整\n时长：3 分钟"))
    pages.append(("11_five_in_one", slide_hub(11, "它的新，不在单点，而在“五环合一”", "OpenClaw 让多个原本分散的 Agent 能力第一次以可体验的方式闭环。", ("五环", "合一"), [
        {"title": "Gateway", "body": "消息路由、通道适配、会话管理", "icon": "cloud", "color": C["blue"]},
        {"title": "真实执行", "body": "浏览器、Shell、文件 API", "icon": "toolbox", "color": C["red"]},
        {"title": "Skills", "body": "能力资产化、可热加载", "icon": "code", "color": C["green"]},
        {"title": "记忆", "body": "本地持久、可读可编辑", "icon": "database", "color": C["orange"]},
        {"title": "调度", "body": "周期唤醒、长期在线", "icon": "clock", "color": C["muted"]},
        {"title": "治理", "body": "安全边界仍需补齐", "icon": "shield-check", "color": C["risk"]},
    ]), "OpenClaw 的传播力来自组合创新，不是某个单点技术突破。\n要点：① 入口 ② 执行 ③ 记忆 ④ 技能 ⑤ 调度\n时长：2 分钟"))
    pages.append(("12_ecosystem_position", slide_table(12, "OpenClaw 是现象级入口，不是所有 Agent 问题的答案", "不同系统处在不同层级，不能用一个维度比较好坏。", ["对象", "核心定位", "更强项", "更弱项"], [
        ["OpenClaw", "开源通用行动型 Agent", "入口传播、环境执行", "治理和稳定性不足"],
        ["Codex", "多代理编程工作台", "软件工程、长任务协作", "偏编码场景"],
        ["Claude Code", "终端编码代理", "代码理解、审批控制", "非通用企业代理"],
        ["Gemini CLI", "Google 系终端 Agent", "开源 CLI、工具链", "通用工作流有限"],
        ["DeerFlow", "深度研究多 Agent 框架", "研究流程、检索执行", "偏 research"],
        ["LangGraph", "Agent 编排底座", "状态化、长任务、可部署", "需要自己搭系统"],
    ], highlight_col=0), "这里不是排名，而是定位。热点入口、成熟产品和工程底座解决的问题不同。\n要点：① OpenClaw 是入口样板 ② Codex/Claude Code 偏产品 ③ LangGraph 偏底座\n时长：3 分钟"))
    pages.append(("13_industry_signal", slide_hub(13, "OpenClaw 未必是终局，但它点燃了 Agent OS 想象", "真正值得关注的是一个新类别开始成形。", ("Agent", "Workforce"), [
        {"title": "个人代理", "body": "日程、邮件、生活任务", "icon": "users", "color": C["blue"]},
        {"title": "办公代理", "body": "文档、流程、审批", "icon": "book-open", "color": C["red"]},
        {"title": "编程代理", "body": "代码、测试、审查", "icon": "code", "color": C["green"]},
        {"title": "研究代理", "body": "检索、摘要、报告", "icon": "book-open", "color": C["orange"]},
        {"title": "客服代理", "body": "问答、工单、回访", "icon": "comment", "color": C["muted"]},
        {"title": "运营代理", "body": "发布、复盘、监控", "icon": "chart-bar", "color": C["risk"]},
    ]), "不要只盯着 OpenClaw 本身，更要看它背后点燃的类别。\n要点：① 新类别成形 ② 入口会多样化 ③ 企业要建设平台能力\n时长：2 分钟"))
    pages.append(("14_industrialization_gap", slide_compare(14, "企业要的不是“能跑起来”，而是“稳定、可控、可审计”", "OpenClaw 重要，但不能直接作为企业级标准答案。", "OpenClaw 的优势", ["形态新，演示冲击强", "执行能力直观", "聊天入口自然", "传播性和想象空间高"], "企业落地门槛", ["稳定性和责任边界", "权限治理与隔离", "审计留痕和回放", "组织级部署与集成"], C["green"], C["red"]), "把“热”和“可落地”拆开讲。企业买的不是演示，而是可控结果。\n要点：① 能跑不等于能上生产 ② 治理是门槛 ③ OpenClaw 更像能力样板\n时长：2 分钟"))
    pages.append(("15_personal_agent", slide_case_image(15, "个人场景里，Agent 开始替人跑流程", "最容易让大众理解的是“它真的在替我做事”。", "个人生活案例占位：订票、浇花、充电、日程", [("多步骤", "需要跨页面、跨工具完成，不只是回答。", C["blue"]), ("低风险", "适合先由个人场景演示和验证。", C["green"]), ("可确认", "关键动作应保留人工确认。", C["red"])]), "个人场景适合让大家快速理解 Agent 的直观价值。\n要点：① 替人跑流程 ② 适合演示 ③ 不等于企业生产可照搬\n时长：2 分钟"))
    pages.append(("16_content_workflow", slide_process(16, "当 Agent 接入内容流程，一个人可以管理更多账号和素材", "Agent 对内容生产的冲击来自批量化、流程化和持续执行。", [
        {"title": "选题", "body": "抓取热点和历史表现，生成候选主题。", "color": C["blue"]},
        {"title": "检索", "body": "收集资料、评论、竞品内容和素材。", "color": C["red"]},
        {"title": "生成", "body": "形成草稿、标题、摘要和配图建议。", "color": C["green"]},
        {"title": "审核", "body": "人工把关质量、版权和平台规则。", "color": C["orange"]},
        {"title": "复盘", "body": "跟踪数据，反向优化选题和模板。", "color": C["muted"]},
    ], "效率提升必须和质量、版权、合规一起设计。"), "内容创作场景容易显出效率，但也最容易放大低质量和合规问题。\n要点：① 批量化 ② 流程化 ③ 人工审核仍是关键\n时长：2 分钟"))
    pages.append(("17_enterprise_scenarios", slide_table(17, "企业真正关心的是客服、投研、代码、采购等可控流程", "Agent 的企业价值在可审计、可授权的流程中更容易落地。", ["场景", "Agent 可做", "人工把关", "落地前提"], [
        ["客服", "知识检索、回复草稿", "重要回复确认", "知识库和审计"],
        ["投研", "资料收集、摘要、图表", "结论和引用核验", "来源管理"],
        ["代码", "变更理解、风险提示", "合并和发布审批", "隔离工作区"],
        ["采购", "询价整理、邮件草稿", "报价和合同确认", "审批流集成"],
    ], highlight_col=3), "企业价值不是“全自动”，而是把可控流程中重复、繁琐、低风险部分代理化。\n要点：① 场景要可审计 ② 权限要可授权 ③ 人工把关不可省\n时长：2.5 分钟"))
    pages.append(("18_hardware_extension", slide_case_image(18, "当 Agent 连上硬件，想象空间会变得更直观", "硬件玩法强化了“数字代理能影响物理世界”的认知冲击。", "硬件/边缘设备占位：ESP32、树莓派、智能家居", [("机会", "低成本验证设备联动、边缘感知和指令执行。", C["green"]), ("边界", "物理误操作、设备安全和责任归属更敏感。", C["risk"]), ("建议", "先做内网、低权限、可回滚的受控 PoC。", C["blue"])]), "硬件场景很有冲击力，但风险也更实在。\n要点：① 影响物理世界 ② 适合受控 PoC ③ 权限必须严格限定\n时长：1.5 分钟"))
    pages.append(("19_myths", slide_compare(19, "热潮之下有噪音，先把四个误区讲清楚", "理性看待 OpenClaw，既不神化，也不妖魔化。", "常见误区", ["所有上门安装都可信", "不养龙虾就会被淘汰", "养虾零成本且稳赚", "所有福利链接都可信"], "正确判断", ["选择正规渠道并核验来源", "它是工具，不是立即替代", "Token、云资源和电费都有成本", "福利和注册链接要走官方路径"], C["risk"], C["green"]), "这页用于缓解焦虑。热潮之下需要把噪音和事实分开。\n要点：① 不神化 ② 不恐慌 ③ 走正规渠道和成本核算\n时长：2 分钟"))
    pages.append(("20_security_concerns", slide_process(20, "Agent 越能干，越需要被治理", "风险来自高权限、跨系统、长期在线和可执行动作的组合。", [
        {"title": "权限", "body": "文件、消息、浏览器、账号、网络访问。", "color": C["red"]},
        {"title": "执行", "body": "脚本、插件、工具调用可能产生真实影响。", "color": C["orange"]},
        {"title": "数据", "body": "敏感信息可能被读取、转发或外泄。", "color": C["blue"]},
        {"title": "审计", "body": "需要留痕、回放、定位和复现能力。", "color": C["green"]},
        {"title": "责任", "body": "必须明确谁授权、谁复核、谁承担。", "color": C["muted"]},
    ], "Agent 不是不能上，而是必须带着安全治理框架上。"), "风险不是用来吓人的，而是用来定义工程边界。\n要点：① 高权限带来高风险 ② 审计和责任必须前置 ③ 治理框架先于规模推广\n时长：2 分钟"))
    pages.append(("21_risk_matrix", slide_grid(21, "六类风险决定了企业能不能放心用", "企业部署 Agent 需要先定义风险边界。", [
        {"title": "Prompt 注入", "body": "恶意网页或内容诱导泄密。", "icon": "shield-half", "color": C["risk"]},
        {"title": "插件投毒", "body": "未知 Skills 或脚本窃取密钥。", "icon": "code", "color": C["risk"]},
        {"title": "公网暴露", "body": "实例裸奔、鉴权不足。", "icon": "cloud", "color": C["orange"]},
        {"title": "误操作", "body": "删除邮件、文件或错误提交。", "icon": "toolbox", "color": C["orange"]},
        {"title": "成本陷阱", "body": "Token、电费、云资源失控。", "icon": "chart-line", "color": C["blue"]},
        {"title": "伦理监管", "body": "冒用身份、越权执行、责任不清。", "icon": "lock-closed", "color": C["muted"]},
    ], cols=3), "这六类风险基本覆盖企业试点时最常见的问题。\n要点：① 安全 ② 成本 ③ 责任\n时长：2 分钟"))
    pages.append(("22_safe_usage", slide_grid(22, "公司要的是“沙箱 + 审计 + 权限分级”的 Agent", "正确落地不是追最新工具，而是先搭治理框架。", [
        {"title": "开启沙箱", "body": "默认只读和人工审核权限。", "icon": "shield-check", "color": C["green"]},
        {"title": "禁止公网暴露", "body": "优先公司内网或受控网络。", "icon": "lock-closed", "color": C["red"]},
        {"title": "每周审计", "body": "重要操作必须二次确认。", "icon": "eye", "color": C["blue"]},
        {"title": "可信插件", "body": "只从可信来源安装。", "icon": "badge-check", "color": C["green"]},
        {"title": "预算上限", "body": "Token 和云资源提前审批。", "icon": "chart-bar", "color": C["orange"]},
    ], cols=5), "这页可以作为内部试点准入规则的雏形。\n要点：① 沙箱 ② 审计 ③ 权限分级 ④ 预算\n时长：2 分钟"))
    pages.append(("23_agent_workforce", slide_quote(23, "真正变化的是 Agent Workforce 的兴起", "企业未来竞争不在“谁先装一个龙虾”，而在“谁先构建可控数字劳动力体系”。", "OpenClaw 是信号弹，Agent Workforce 才是长期变量。", [("新类别", "个人、办公、编程、研究、客服、运营代理开始成形。", "robot"), ("关键能力", "权限治理、系统集成、长期记忆、多代理协同。", "toolbox"), ("竞争焦点", "可信、可控、可验证的执行体系。", "shield-check")]), "把技术分享提升到业务判断：我们关注的是数字劳动力体系，不是单个热点。\n要点：① 类别形成 ② 能力体系 ③ 长期竞争焦点\n时长：2 分钟"))
    pages.append(("24_internal_strategy", slide_hub(24, "重点不是复制 OpenClaw，而是吸收关键能力", "公司应围绕关键模块做系统拆解、能力沉淀和内部验证。", ("公司", "Agent 底座"), [
        {"title": "入口", "body": "IM、Web、API 多入口", "icon": "comment", "color": C["blue"]},
        {"title": "记忆", "body": "可检索、可清理、可审计", "icon": "database", "color": C["green"]},
        {"title": "执行", "body": "工具运行时、沙箱、重试", "icon": "toolbox", "color": C["red"]},
        {"title": "调度", "body": "长任务、周期任务、事件驱动", "icon": "clock", "color": C["orange"]},
        {"title": "Skills", "body": "能力资产化和复用", "icon": "code", "color": C["muted"]},
        {"title": "治理", "body": "权限、审计、责任边界", "icon": "shield-check", "color": C["risk"]},
    ]), "公司不需要复制一个 OpenClaw，而要把关键能力沉淀进自己的技术体系。\n要点：① 系统拆解 ② 能力沉淀 ③ 内部低风险验证\n时长：2 分钟"))
    pages.append(("25_roadmap", slide_roadmap(), "阶段推进要讲目标、动作和产出，不要只讲口号。\n要点：① 短期看清楚 ② 中期补能力 ③ 长期沉淀体系\n时长：2.5 分钟"))
    pages.append(("26_productization", slide_columns(26, "从内部试点到企业级封装，再到全栈集成平台", "研发部门可以把技术理解转化为可交付能力。", [
        {"title": "短期：内部试点", "color": C["blue"], "items": ["一键部署模板", "沙箱模式", "风险监控仪表盘"]},
        {"title": "中期：企业封装", "color": C["red"], "items": ["多 Agent 协作矩阵", "合规审计报告", "关键操作二次确认"]},
        {"title": "长期：全栈集成", "color": C["green"], "items": ["对接 OA / ERP / 知识中台", "全员使用规范", "安全可控助手"]},
    ]), "这里面向管理层：把“能做什么”讲成路线、能力和边界。\n要点：① 试点 ② 封装 ③ 集成\n时长：2 分钟"))
    pages.append(("27_silicon_employee", slide_columns(27, "“硅基员工”是好比喻，但不能被神化", "硅基员工不是人类替身，而是可编排、可监督、可复制的任务执行体。", [
        {"title": "它像员工", "color": C["green"], "items": ["能接任务", "能拆步骤", "能调用工具", "能交付阶段结果"]},
        {"title": "它不像员工", "color": C["risk"], "items": ["没有稳定常识边界", "不能天然承担责任", "复杂环境容易误判", "对权限极其敏感"]},
        {"title": "它更像什么", "color": C["blue"], "items": ["可培训", "可连接系统", "可规模复制", "可监督的数字劳动力单元"]},
    ]), "愿景要讲，但不能过度承诺。\n要点：① 像员工 ② 不像员工 ③ 更像任务执行体\n时长：2 分钟"))
    pages.append(("28_maturity_path", slide_stairs(), "问答助手不是终点，真正的跃迁在流程代理和多代理协同。\n要点：① 问答 ② 工具调用 ③ 流程代理 ④ 多代理协同\n时长：2 分钟"))
    pages.append(("29_ppt_workflow", slide_process(29, "这份演示本身就是一次大模型辅助工作流", "AI 已经可以参与调研、整理、结构迭代和幻灯片生成，但仍需要人类判断和校验。", [
        {"title": "清单", "body": "先拟定内容框架和核心问题。", "color": C["blue"]},
        {"title": "整理", "body": "汇总材料、新闻、讨论和竞品。", "color": C["red"]},
        {"title": "迭代", "body": "反复调整技术本质、风险和愿景。", "color": C["green"]},
        {"title": "生成", "body": "形成逐页文案、布局和讲稿。", "color": C["orange"]},
        {"title": "校验", "body": "人类负责取舍、事实核验和风险边界。", "color": C["muted"]},
    ], "用 AI 讲 AI，但最后仍由人负责判断。"), "用这页呼应开场：这份材料本身就是 AI 辅助工作流的一个缩影。\n要点：① AI 辅助 ② 人类判断 ③ 事实和风险仍需校验\n时长：1.5 分钟"))
    pages.append(("30_close", slide_close(), "结尾把所有内容收束到人机协作方式的变化。\n要点：① 从会回答到会执行 ② 从被操作到可委托 ③ 从 AI 工具到组织数字劳动力\n时长：1 分钟"))
    return pages


def main():
    if PROJECT.name != "openclaw-agent-ppt-20260430-pptx_ppt169_20260430":
        raise SystemExit("Unexpected project path; refusing to generate.")
    SVG_DIR.mkdir(parents=True, exist_ok=True)
    NOTES_DIR.mkdir(parents=True, exist_ok=True)
    for p in SVG_DIR.glob("*.svg"):
        p.unlink()
    pages = build_pages()
    notes = []
    for stem, content, note in pages:
        (SVG_DIR / f"{stem}.svg").write_text(content, encoding="utf-8")
        notes.append(f"# {stem}\n\n{note.strip()}\n")
    (NOTES_DIR / "total.md").write_text("\n---\n\n".join(notes), encoding="utf-8")
    print(f"Generated {len(pages)} SVG slides and notes/total.md")


if __name__ == "__main__":
    main()
