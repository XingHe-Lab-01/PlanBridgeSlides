# OpenClaw Agent Internal Briefing - Design Spec

> This document is the unified handoff artifact for design definition and execution constraints. It combines visual specifications, content outline, speaker-notes requirements, and implementation boundaries needed by downstream roles.

## I. Project Information

| Item | Value |
| ---- | ----- |
| **Project Name** | OpenClaw Agent Internal Briefing |
| **Canvas Format** | PPT 16:9 (1280x720) |
| **Page Count** | 30 |
| **Design Style** | Free design, General Consulting, technology training + management briefing |
| **Target Audience** | 公司内部管理层、研发团队、产品团队、解决方案团队、AI 应用推进相关同事 |
| **Use Case** | 内部培训、技术分享、部门汇报、Agent 方向认知统一会 |
| **Created Date** | 2026-04-30 |

---

## II. Canvas Specification

| Property | Value |
| -------- | ----- |
| **Format** | PPT 16:9 |
| **Dimensions** | 1280x720 |
| **viewBox** | `0 0 1280 720` |
| **Margins** | left/right 56px, top 42px, bottom 34px |
| **Content Area** | 1168x620, with title band 86px, main content 500px, footer 34px |

---

## III. Visual Theme

### Theme Style

- **Style**: Free design; conclusion-first consulting deck with modern AI technology tone
- **Theme**: Light theme for content pages; dark red/charcoal accent for cover and closing pages
- **Tone**: Professional, structured, internal-training, technology-forward, risk-aware

### Color Scheme

| Role | HEX | Purpose |
| ---- | --- | ------- |
| **Background** | `#FFFFFF` | Main page background |
| **Secondary bg** | `#F4F6F8` | Panels, cards, diagrams |
| **Primary** | `#1F2933` | Core title, dark section blocks, structural text |
| **Accent** | `#D71920` | OpenClaw red, key warnings, headline emphasis |
| **Secondary accent** | `#2563A6` | Technical diagrams, connectors, neutral emphasis |
| **Body text** | `#23313F` | Main body text |
| **Secondary text** | `#5B6775` | Captions, annotations |
| **Tertiary text** | `#8A94A3` | Footers, source notes |
| **Border/divider** | `#D9E0E7` | Card borders, divider lines |
| **Success** | `#2E7D32` | Safe usage, positive indicators |
| **Warning** | `#C62828` | Risk markers, prohibition, alert content |

### Gradient Scheme

Use gradients only for cover bands, section accents, and title highlights. Do not use decorative blobs.

```xml
<linearGradient id="headerGrad" x1="0%" y1="0%" x2="100%" y2="0%">
  <stop offset="0%" stop-color="#1F2933"/>
  <stop offset="100%" stop-color="#D71920"/>
</linearGradient>
```

---

## IV. Typography System

### Font Plan

**Recommended preset**: P1 Modern business / tech

| Role | Chinese | English | Fallback |
| ---- | ------- | ------- | -------- |
| **Title** | Microsoft YaHei | Arial | SimHei |
| **Body** | Microsoft YaHei | Calibri | Arial |
| **Code** | - | Consolas | Monaco |
| **Emphasis** | SimHei | Arial | Microsoft YaHei |

**Font stack**: `Microsoft YaHei, Arial, Calibri, sans-serif`

### Font Size Hierarchy

**Baseline**: Body font size = 18px, with 20px used for low-density pages.

| Purpose | Size | Weight |
| ------- | ---- | ------ |
| Cover title | 56-64px | Bold |
| Section / closing title | 44-52px | Bold |
| Content title | 32-38px | Bold |
| Subtitle / takeaway | 22-26px | SemiBold |
| **Body content** | **18-20px** | Regular |
| Annotation | 13-15px | Regular |
| Page number/date | 11-12px | Regular |

---

## V. Layout Principles

### Page Structure

- **Header area**: 42-116px, title and section marker. Most pages use a concise conclusion-first title.
- **Content area**: 118-650px, diagrams, cards, tables, matrices, or case placeholders.
- **Footer area**: 666-700px, page number, confidentiality marker, optional source note.

### Common Layout Modes

| Mode | Suitable Scenarios |
| ---- | ----------------- |
| **Single column centered** | Cover, closing, major strategic statements |
| **Left-right split (5:5)** | Concept comparisons, image-placeholder + explanation |
| **Left-right split (4:6)** | Case pages and screenshot placeholders |
| **Top-bottom split** | Timelines, processes, roadmap pages |
| **Three/four column cards** | Capabilities, risk cards, action plans |
| **Matrix grid** | Product/ecosystem comparison, enterprise scenario classification |

### Spacing Specification

| Element | Recommended Range | Current Project |
| ------- | ---------------- | --------------- |
| Card gap | 20-32px | 24px |
| Content block gap | 24-40px | 28px |
| Card padding | 18-28px | 22px |
| Card border radius | 6-10px | 8px |
| Icon-text gap | 8-16px | 12px |
| Single-row card height | 500-560px | 520px |
| Double-row card height | 230-255px each | 238px |
| Three-column card width | 360-372px each | 360px |

---

## VI. Icon Usage Specification

### Source

- **Built-in icon library**: `templates/icons/chunk/`
- **Usage method**: Placeholder format `{{icon:chunk/icon-name}}`
- **Rule**: One presentation = one library. Use `chunk` only.

### Recommended Icon List

| Purpose | Icon Path | Page |
| ------- | --------- | ---- |
| Agent / automation | `{{icon:chunk/robot}}` | 01, 04, 07, 23, 27 |
| Technology / compute | `{{icon:chunk/code}}` | 08, 09, 10, 12 |
| Tools / execution | `{{icon:chunk/toolbox}}` | 04, 09, 11 |
| Memory / data | `{{icon:chunk/database}}` | 08, 09, 24 |
| Cloud / deployment | `{{icon:chunk/cloud}}` | 06, 13, 26 |
| Security | `{{icon:chunk/shield-check}}` | 20, 21, 22 |
| Risk / warning | `{{icon:chunk/triangle-exclamation}}` if available; otherwise draw custom triangle | 19, 20, 21 |
| Governance / lock | `{{icon:chunk/lock-closed}}` | 14, 22 |
| Roadmap / timeline | `{{icon:chunk/calendar}}` | 05, 25, 28 |
| Audience / organization | `{{icon:chunk/users}}` | 03, 17, 26 |
| Metrics / chart | `{{icon:chunk/chart-bar}}` | 10, 17, 25 |
| Search / research | `{{icon:chunk/book-open}}` | 12, 24, 29 |

---

## VII. Visualization Reference List

| Visualization Type | Reference Template | Used In |
| ------------------ | ------------------ | ------- |
| timeline | `templates/charts/timeline.svg` | Slide 05 |
| process_flow | `templates/charts/process_flow.svg` | Slides 07, 16, 20, 29 |
| icon_grid | `templates/charts/icon_grid.svg` | Slides 03, 06, 21, 22 |
| hub_spoke | `templates/charts/hub_spoke.svg` | Slides 11, 13, 24 |
| comparison_table | `templates/charts/comparison_table.svg` | Slides 10, 12, 17 |
| pros_cons_chart | `templates/charts/pros_cons_chart.svg` | Slides 04, 14, 19 |
| roadmap_vertical | `templates/charts/roadmap_vertical.svg` | Slide 25 |
| isometric_stairs | `templates/charts/isometric_stairs.svg` | Slide 28 |
| vertical_list | `templates/charts/vertical_list.svg` | Slides 15, 18, 23, 27, 30 |

---

## VIII. Image Resource List

| Filename | Dimensions | Ratio | Purpose | Type | Status | Generation Description |
| -------- | --------- | ----- | ------- | ---- | ------ | --------------------- |
| cover_visual_placeholder | 1280x720 | 1.78 | Cover background visual | Diagram | Placeholder | SVG-drawn red claw/agent network motif; no external image required |
| phenomenon_screenshot_placeholder | 520x360 | 1.44 | Opening social phenomenon screenshot area | Photography | Placeholder | Replace later with verified queue/social screenshot if available |
| case_life_placeholder | 520x360 | 1.44 | Personal life use case area | Photography | Placeholder | Replace later with verified video still or screenshot |
| case_content_placeholder | 520x360 | 1.44 | Content workflow case area | Diagram | Placeholder | SVG-drawn workflow is sufficient |
| case_hardware_placeholder | 520x360 | 1.44 | Hardware and edge device case area | Photography | Placeholder | Replace later with verified device image if available |

---

## IX. Content Outline

### Part 1: Opening and Context

#### Slide 01 - Cover

- **Layout**: Dark accented hero cover, large title, SVG-drawn agent network and red claw motif.
- **Title**: OpenClaw：从“养一只龙虾”到硅基员工革命
- **Content**: 2026 年开源 AI Agent 现象级案例深度内部科普；内部培训；AI 辅助制作标记。

#### Slide 02 - Opening Hook

- **Layout**: Left placeholder screenshot panel, right insight cards.
- **Title**: 一个开源项目，为什么能让三个圈层同时关注
- **Visualization**: icon_grid
- **Content**: 技术圈、产业圈、安全圈；从“会说”到“会做”；互动提问。

#### Slide 03 - Agenda

- **Layout**: Two-column agenda grid with seven numbered sections.
- **Title**: 45 分钟后，我们要回答两个问题
- **Visualization**: icon_grid
- **Content**: 新在哪里；我们如何吸收；7 个议题。

### Part 2: What OpenClaw Is

#### Slide 04 - What Is OpenClaw

- **Layout**: Comparison left/right.
- **Title**: 它不是聊天机器人，而是“Agent 外壳 + 执行系统”
- **Visualization**: pros_cons_chart
- **Content**: ChatGPT 会说；OpenClaw 会执行；聊天入口驱动真实环境。

#### Slide 05 - Timeline

- **Layout**: Horizontal timeline.
- **Title**: 从个人助手到现象级 Agent 入口
- **Visualization**: timeline
- **Content**: 原型出现；社区扩散；中国热度爆发；产业与安全讨论并行。

#### Slide 06 - Why It Broke Out in China

- **Layout**: Four card grid.
- **Title**: 它踩中了中国用户最熟悉的三类入口
- **Visualization**: icon_grid
- **Content**: 聊天入口、云端入口、设备入口、安全入口。

### Part 3: Technical Core

#### Slide 07 - Workflow Delegation

- **Layout**: Past vs future flow.
- **Title**: 真正改变的不是聊天，而是工作流代理化
- **Visualization**: process_flow
- **Content**: 回答效率 -> 任务完成效率；人调用软件 -> 代理调用软件。

#### Slide 08 - Eight Layers

- **Layout**: Eight-layer architecture stack.
- **Title**: 从外面看是“龙虾”，从里面看是八层系统
- **Visualization**: custom architecture stack
- **Content**: Orchestrator、Planner、Tool Runtime、Connector、Context、Memory、Safety、Eval。

#### Slide 09 - Three-Layer OpenClaw Architecture

- **Layout**: Three-layer architecture diagram.
- **Title**: Gateway、Agent Runtime、Skills 组成行动型 Agent 框架
- **Visualization**: custom architecture map
- **Content**: 消息中枢、运行时、技能生态；数字劳动力公式。

#### Slide 10 - Compared With Previous Agent Frameworks

- **Layout**: Structured comparison table.
- **Title**: 从实验性 Agent，到可持续运行的数字劳动力
- **Visualization**: comparison_table
- **Content**: 入口、执行、记忆、持久性、扩展、部署。

#### Slide 11 - Four Innovations

- **Layout**: Hub-and-spoke.
- **Title**: 它的新，不在单点，而在“五环合一”
- **Visualization**: hub_spoke
- **Content**: Gateway、执行层、Skills、记忆、调度闭环。

### Part 4: Ecosystem and Industry

#### Slide 12 - Ecosystem Positioning

- **Layout**: Positioning matrix/table.
- **Title**: OpenClaw 是现象级入口，不是所有 Agent 问题的答案
- **Visualization**: comparison_table
- **Content**: OpenClaw、Codex、Claude Code、Gemini CLI、DeerFlow、LangGraph。

#### Slide 13 - Industry Signal

- **Layout**: Ecosystem hub.
- **Title**: OpenClaw 未必是终局，但它点燃了 Agent OS 想象
- **Visualization**: hub_spoke
- **Content**: 个人、办公、编程、研究、销售、客服、运营代理。

#### Slide 14 - Industrialization Gap

- **Layout**: Pros vs enterprise requirements.
- **Title**: 企业要的不是“能跑起来”，而是“稳定、可控、可审计”
- **Visualization**: pros_cons_chart
- **Content**: 优势与产业化门槛。

### Part 5: Use Cases and Risks

#### Slide 15 - Personal Life Agent

- **Layout**: Case placeholder + three-step flow.
- **Title**: 个人场景里，Agent 开始替人跑流程
- **Visualization**: vertical_list
- **Content**: 订机票、日程、邮件、浇花、充电；接任务 -> 调工具 -> 汇报。

#### Slide 16 - Content Workflow

- **Layout**: Process pipeline.
- **Title**: 当 Agent 接入内容流程，一个人可以管理更多账号和素材
- **Visualization**: process_flow
- **Content**: 选题、检索、生成、审核、发布、复盘。

#### Slide 17 - Enterprise Productivity

- **Layout**: Four-quadrant scenario matrix.
- **Title**: 企业真正关心的是客服、投研、代码、采购等可控流程
- **Visualization**: comparison_table
- **Content**: 四类场景及前提条件。

#### Slide 18 - Hardware Extension

- **Layout**: Device placeholder + opportunity/boundary split.
- **Title**: 当 Agent 连上硬件，想象空间会变得更直观
- **Visualization**: vertical_list
- **Content**: ESP32、树莓派、智能家居、工厂巡检；机会与边界。

#### Slide 19 - Myths and Misunderstandings

- **Layout**: Myth vs truth comparison.
- **Title**: 热潮之下有噪音，先把四个误区讲清楚
- **Visualization**: pros_cons_chart
- **Content**: 安装可信度、时代焦虑、成本误解、福利链接。

#### Slide 20 - Why Security Concerns Rise

- **Layout**: Risk chain flow.
- **Title**: Agent 越能干，越需要被治理
- **Visualization**: process_flow
- **Content**: 权限、执行、数据、审计、责任。

#### Slide 21 - Six Risk Categories

- **Layout**: 2x3 risk cards.
- **Title**: 六类风险决定了企业能不能放心用
- **Visualization**: icon_grid
- **Content**: Prompt 注入、插件投毒、公网暴露、误操作、成本、伦理监管。

#### Slide 22 - Correct Usage

- **Layout**: Five safety rules.
- **Title**: 公司要的是“沙箱 + 审计 + 权限分级”的 Agent
- **Visualization**: icon_grid
- **Content**: 沙箱、内网、审计、可信插件、预算上限。

### Part 6: Company Action and Future Vision

#### Slide 23 - Strategic Judgment

- **Layout**: Big quote + supporting points.
- **Title**: 真正变化的是 Agent Workforce 的兴起
- **Visualization**: vertical_list
- **Content**: 从单项目到新类别；企业关键能力。

#### Slide 24 - Internal Strategy

- **Layout**: Six-module capability map.
- **Title**: 重点不是复制 OpenClaw，而是吸收关键能力
- **Visualization**: hub_spoke
- **Content**: 入口、记忆、执行、调度、Skills、治理。

#### Slide 25 - Action Roadmap

- **Layout**: Three-stage roadmap.
- **Title**: 短期看清楚，中期补能力，长期沉淀体系
- **Visualization**: roadmap_vertical
- **Content**: 0-3 个月、3-6 个月、6-12 个月。

#### Slide 26 - Productization Plan

- **Layout**: Three capability columns.
- **Title**: 从内部试点到企业级封装，再到全栈集成平台
- **Visualization**: icon_grid
- **Content**: 试点模板、企业级封装、全栈集成平台。

#### Slide 27 - Silicon Employee Definition

- **Layout**: Three-pillar clarification.
- **Title**: “硅基员工”是好比喻，但不能被神化
- **Visualization**: vertical_list
- **Content**: 像员工、不像员工、更像数字劳动力单元。

#### Slide 28 - Maturity Path

- **Layout**: Four-stage staircase.
- **Title**: 真正的硅基员工雏形，出现在流程代理和多代理协同阶段
- **Visualization**: isometric_stairs
- **Content**: 问答助手、工具调用、流程代理、多代理协同。

#### Slide 29 - This PPT Workflow

- **Layout**: AI-assisted production flow.
- **Title**: 这份演示本身就是一次大模型辅助工作流
- **Visualization**: process_flow
- **Content**: 内容清单、检索整理、结构迭代、逐页生成、人工校验。

#### Slide 30 - Closing

- **Layout**: Big closing statement.
- **Title**: OpenClaw 只是开始，真正变化的是人机协作方式
- **Visualization**: vertical_list
- **Content**: 从会回答到会执行；从被操作到可委托；从 AI 工具到组织数字劳动力。

---

## X. Speaker Notes Requirements

Generate corresponding speaker note files for each page, saved to the `notes/` directory:

- **File naming**: Match SVG names, e.g., `01_cover.md`
- **Total file**: `notes/total.md` must use one level-1 heading per slide matching SVG stems.
- **Content includes**: Script key points, timing cues, transition phrases.
- **Duration**: 40-45 minutes total.
- **Notes style**: Professional but conversational Chinese; internal training tone.
- **Purpose**: Inform, align understanding, and guide controlled internal experimentation.

---

## XI. Technical Constraints Reminder

### SVG Generation Must Follow:

1. viewBox: `0 0 1280 720`
2. Background uses `<rect>` elements
3. Text wrapping uses `<tspan>` (`<foreignObject>` FORBIDDEN)
4. Transparency uses `fill-opacity` / `stroke-opacity`; `rgba()` FORBIDDEN
5. FORBIDDEN: `clipPath`, `mask`, `<style>`, `class`, `foreignObject`
6. FORBIDDEN: `textPath`, `animate*`, `script`
7. `marker-start` / `marker-end` conditionally allowed: `<marker>` must be in `<defs>`, `orient="auto"`, shape must be triangle / diamond / circle

### PPT Compatibility Rules:

- `<g opacity="...">` FORBIDDEN; set opacity on each child element individually.
- Image transparency uses overlay mask layer.
- Inline styles only; external CSS and `@font-face` FORBIDDEN.
