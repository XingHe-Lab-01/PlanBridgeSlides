# planbridgeslides-skill-grgppt-v2-20260430

This project was initialized by `grgppt-v2`.

## Layout

- `planning/`: shared planning workspace and source archive
- `planning/slides_plan.md`: shared content outline and planning document
- `planning/sources/`: raw source materials or their copies
- `html/`: HTML branch workspace; receives its own copy of `slides_plan.md`
- `pptx/`: PPTX branch workspace; receives its own copy of `slides_plan.md`
- `output/`: final verified artifacts copied from the selected branch
