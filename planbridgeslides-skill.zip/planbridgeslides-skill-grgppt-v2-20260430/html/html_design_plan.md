# HTML 分支设计计划

## Chosen Theme

- 主主题：`engineering-whiteprint`
- 可切换备选：`corporate-clean`、`academic-paper`
- 选择理由：内容是技术方案与研究汇报，适合白底网格、工程图、流程图和指标矩阵；避免把论文内容做成重装饰页面。

## Chosen Starting Template

- 起手模板：`tech-sharing`
- 使用方式：保留其技术分享 deck 的节奏和 runtime 结构，但将局部样式调整为工程白图风格，并改写为 PlanBridgeSlides skill 的 12 页内容。

## Slide-to-Layout Mapping

| 页码 | 标题 | 布局 |
| ---- | ---- | ---- |
| 01 | PlanBridgeSlides skill | Hero cover |
| 02 | 高质量 PPT 生成不是“一键生成” | Insight + tradeoff triangle |
| 03 | 主流 PPT 生成路线分成四类 | 2x2 comparison matrix |
| 04 | 统一策划，分支交付 | Architecture split |
| 05 | 四目录工作区 | Directory architecture |
| 06 | `slides_plan.md` 是内容真相源 | Process flow |
| 07 | HTML 分支 | Branch walkthrough |
| 08 | PPTX 分支 | Branch walkthrough |
| 09 | 模板约束 | Three-pillar |
| 10 | 清晰中间态 | Quality gates |
| 11 | 七维评价框架 | Metric cards |
| 12 | 受控生成 + 草稿编辑 + 模板资产库 | Closing CTA |

## Runtime Feature Decisions

- 保留 `runtime.js`，支持方向键翻页、主题切换、overview、notes drawer 和 presenter mode。
- 使用 `data-themes="engineering-whiteprint,corporate-clean,academic-paper"`。
- 默认导出 standalone HTML。

## Notes Strategy

- 每页包含 `<aside class="notes">`，用于 presenter mode 与 notes drawer。
- notes 使用口语化提示，帮助讲者从论文式材料切换为技术汇报表达。
