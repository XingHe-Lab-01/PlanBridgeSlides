from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter
import math
import random
import textwrap

ROOT = Path(__file__).resolve().parent
SVG_DIR = ROOT / "svg_output"
IMG_DIR = ROOT / "images"
NOTES_DIR = ROOT / "notes"

W, H = 1280, 720
BG = "#F4F1EC"
BG2 = "#E7E2DA"
PRIMARY = "#6F8796"
SECONDARY = "#9AAE9A"
ACCENT = "#C08F80"
TEXT = "#2F3437"
MUTED = "#6C7478"
BORDER = "#D8D1C8"
WHITE = "#FBFAF7"
FONT = "'Microsoft YaHei', Arial, sans-serif"

slides = [
    {
        "file": "01_封面.svg",
        "title": "PlanBridgeSlides skill",
        "takeaway": "模板约束与清晰中间态的高可用幻灯片生成方法",
        "section": "问题与研究定位",
        "kind": "cover",
        "bullets": ["Agent Skills", "自动化 PPT", "统一策划", "分支交付", "可编辑草稿"],
        "note": "本次汇报的核心不是介绍一个单点工具，而是说明一种 slides skill 的构造方法：先稳定内容规划，再按 HTML 和 PPTX 两条路径交付。",
    },
    {
        "file": "02_真实瓶颈.svg",
        "title": "高质量 PPT 生成不是一键生成，而是可控草稿生产",
        "takeaway": "普通用户真正需要的是低成本、高质量、可继续编辑的演示草稿。",
        "section": "问题与研究定位",
        "kind": "tradeoff",
        "bullets": ["组织材料", "结构化内容", "排版表达", "反复修改"],
        "note": "自动化 PPT 生成的瓶颈不只是视觉美观，而是轻量部署、稳定输出和后续可编辑三者同时成立。",
    },
    {
        "file": "03_路线边界.svg",
        "title": "主流 PPT 生成路线分成四类，各有适用边界",
        "takeaway": "没有绝对最优路线，关键是根据交付需求选择中间表示和输出格式。",
        "section": "路线比较",
        "kind": "matrix",
        "bullets": ["HTML 直接输出", "非编辑型 PPTX", "HTML-to-PPTX", "SVG-to-PPTX"],
        "note": "路线比较的目的不是排名，而是引出混合分层设计：不同输出格式服务不同交付场景。",
    },
    {
        "file": "04_统一策划.svg",
        "title": "PlanBridgeSlides skill 的目标是统一策划，分支交付",
        "takeaway": "先稳定内容事实和页面结构，再让 HTML 与 PPTX 分支各自发挥格式优势。",
        "section": "方案设计",
        "kind": "converge",
        "bullets": ["HTML：分享与交互", "PPTX：离线编辑", "planning：内容真相源"],
        "note": "这里的混合不是两套系统简单相加，而是分层：共享策划层解决讲什么，分支阶段解决做成什么。",
    },
    {
        "file": "05_四目录工作区.svg",
        "title": "四个顶层目录定义生成过程的可检查边界",
        "takeaway": "目录结构把内容规划、分支设计、生成和交付都暴露为可检查中间态。",
        "section": "方案设计",
        "kind": "folders",
        "bullets": ["planning/", "html/", "pptx/", "output/"],
        "note": "四目录工作区的价值在于降低不可见失败。每个目录都对应一个可检查、可修正、可接管的阶段。",
    },
    {
        "file": "06_内容真相源.svg",
        "title": "先把“讲什么”固定，再讨论“做成什么”",
        "takeaway": "共享策划层把异构输入整理为两条分支都能复用的内容规划。",
        "section": "方案设计",
        "kind": "flow",
        "bullets": ["源材料归档", "内容标准化", "slides_plan.md", "可用性自检", "分支选择"],
        "note": "共享策划层减少后续分支重复分析，也避免一开始就被视觉模板牵着走。",
    },
    {
        "file": "07_HTML分支.svg",
        "title": "HTML 分支面向轻量分享和交互演示",
        "takeaway": "HTML 交付适合快速打开、分享和演示，并保留 presenter mode 等运行能力。",
        "section": "分支机制",
        "kind": "branch",
        "bullets": ["theme / layout", "runtime", "presenter notes", "standalone HTML"],
        "note": "HTML 分支不是低配路径，它的优势是低摩擦分享和交互演示，适合快速传播和审阅。",
    },
    {
        "file": "08_PPTX分支.svg",
        "title": "PPTX 分支把共享规划转为可编辑的原生 PowerPoint",
        "takeaway": "PPTX 分支更强调结构化生成、后处理控制和可编辑对象。",
        "section": "分支机制",
        "kind": "branch",
        "bullets": ["模板确认", "Eight Confirmations", "design_spec.md", "SVG 后处理", "文本安全检查"],
        "note": "PPTX 分支的关键是不要直接截图交付，而是通过 SVG 中间态、后处理和 native 导出提升可编辑性。",
    },
    {
        "file": "09_模板约束.svg",
        "title": "模板不是限制创造力，而是给模型可控边界",
        "takeaway": "模板库把页面结构和视觉表达限制在可验证范围内，减少自由布局漂移。",
        "section": "核心机制",
        "kind": "pillars",
        "bullets": ["约束对象", "降低风险", "保留弹性"],
        "note": "模板的作用是约束生成空间。约束越清晰，模型越容易稳定地产出可检查的页面。",
    },
    {
        "file": "10_质量门.svg",
        "title": "每个中间产物都是一次可检查的质量门",
        "takeaway": "内容规划、分支设计、页面生成、后处理和最终交付被分层暴露。",
        "section": "核心机制",
        "kind": "gates",
        "bullets": ["内容层", "分支层", "生成层", "后处理层", "交付层"],
        "note": "流程看起来多一步，但每一步都让失败更早暴露，也让人工和 Agent 都能更精确地介入修正。",
    },
    {
        "file": "11_评价框架.svg",
        "title": "高可用不只看美观，还要看编辑、稳定和成本",
        "takeaway": "评价体系把主观视觉质量拆成可检查的工程指标。",
        "section": "评价框架",
        "kind": "metrics",
        "bullets": ["文本溢出", "组件遮挡", "可编辑性", "部署成本", "输出稳定性", "模板库容量", "输入支持能力"],
        "note": "如果后续有真实评分，这一页可以升级为雷达图或对比柱状图；当前只呈现指标框架，不虚构实验成绩。",
    },
    {
        "file": "12_结论.svg",
        "title": "未来是受控生成、草稿编辑与模板资产库协作",
        "takeaway": "PPT 生成技能的长期价值在于沉淀组织知识和沟通标准。",
        "section": "结论与未来",
        "kind": "ending",
        "bullets": ["统一策划保证内容一致", "分支执行保留格式优势", "模板资产库沉淀组织标准"],
        "note": "最后收束到三个关键词：可控、可查、可改。PlanBridgeSlides skill 的价值在于让自动化生成更容易被工程化接管。",
    },
]


def ensure_dirs():
    SVG_DIR.mkdir(exist_ok=True)
    IMG_DIR.mkdir(exist_ok=True)
    NOTES_DIR.mkdir(exist_ok=True)


def make_tech_image(name: str, seed: int):
    random.seed(seed)
    img = Image.new("RGB", (W, H), BG)
    draw = ImageDraw.Draw(img, "RGBA")
    for y in range(H):
        t = y / H
        r1, g1, b1 = tuple(int(BG.lstrip("#")[i:i+2], 16) for i in (0, 2, 4))
        r2, g2, b2 = tuple(int(BG2.lstrip("#")[i:i+2], 16) for i in (0, 2, 4))
        draw.line([(0, y), (W, y)], fill=(int(r1*(1-t)+r2*t), int(g1*(1-t)+g2*t), int(b1*(1-t)+b2*t), 255))
    palette = [PRIMARY, SECONDARY, ACCENT]
    pts = [(random.randint(80, W-80), random.randint(70, H-70)) for _ in range(42)]
    for i, p in enumerate(pts):
        for q in pts[i+1:]:
            d = math.hypot(p[0]-q[0], p[1]-q[1])
            if d < 190:
                c = tuple(int(PRIMARY.lstrip("#")[j:j+2], 16) for j in (0, 2, 4))
                draw.line([p, q], fill=(*c, int(70 * (1 - d / 190))), width=1)
    for x, y in pts:
        col = random.choice(palette)
        c = tuple(int(col.lstrip("#")[j:j+2], 16) for j in (0, 2, 4))
        r = random.randint(3, 8)
        draw.ellipse([x-r, y-r, x+r, y+r], fill=(*c, 160))
    for i in range(8):
        x = random.randint(-100, W)
        y = random.randint(0, H)
        draw.arc([x, y-180, x+420, y+180], 200, 340, fill=(111, 135, 150, 50), width=3)
    img = img.filter(ImageFilter.GaussianBlur(0.25))
    path = IMG_DIR / name
    img.save(path)
    return path


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def tspans(text, x, y, size, fill, weight="normal", max_chars=34, line_h=None, anchor="start"):
    line_h = line_h or int(size * 1.35)
    lines = []
    for part in text.split("\n"):
        lines.extend(textwrap.wrap(part, width=max_chars, break_long_words=False) or [""])
    out = [f'<text x="{x}" y="{y}" font-family="{FONT}" font-size="{size}" font-weight="{weight}" fill="{fill}" text-anchor="{anchor}">']
    for i, line in enumerate(lines):
        dy = 0 if i == 0 else line_h
        out.append(f'<tspan x="{x}" dy="{dy}">{esc(line)}</tspan>')
    out.append("</text>")
    return "\n".join(out)


def defs():
    return f"""
  <defs>
    <filter id="shadow" x="-15%" y="-15%" width="140%" height="140%">
      <feGaussianBlur in="SourceAlpha" stdDeviation="8"/>
      <feOffset dx="0" dy="5" result="offsetBlur"/>
      <feFlood flood-color="#6F8796" flood-opacity="0.16" result="shadowColor"/>
      <feComposite in="shadowColor" in2="offsetBlur" operator="in" result="shadow"/>
      <feMerge><feMergeNode in="shadow"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
    <linearGradient id="accentGrad" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="{PRIMARY}"/>
      <stop offset="100%" stop-color="{ACCENT}"/>
    </linearGradient>
    <marker id="arrowHead" markerWidth="10" markerHeight="10" refX="9" refY="5" orient="auto" markerUnits="strokeWidth">
      <path d="M0,0 L10,5 L0,10 Z" fill="{PRIMARY}"/>
    </marker>
  </defs>"""


def header(slide, num):
    return f"""
  <g id="header">
    <rect x="0" y="0" width="1280" height="4" fill="{ACCENT}"/>
    <rect x="0" y="4" width="1280" height="76" fill="{WHITE}"/>
    <line x1="0" y1="80" x2="1280" y2="80" stroke="{BORDER}" stroke-width="1"/>
    <rect x="50" y="20" width="8" height="40" fill="{PRIMARY}"/>
    {tspans(slide["title"], 72, 42, 25, TEXT, "bold", 42)}
  </g>
  <g id="takeaway">
    <rect x="50" y="96" width="1180" height="48" rx="8" fill="{PRIMARY}" fill-opacity="0.10" stroke="{PRIMARY}" stroke-opacity="0.25"/>
    {tspans(slide["takeaway"], 72, 126, 16, TEXT, "bold", 60)}
  </g>"""


def footer(slide, num):
    return f"""
  <g id="footer">
    <rect x="0" y="680" width="1280" height="40" fill="{BG2}"/>
    <rect x="0" y="680" width="4" height="40" fill="{PRIMARY}"/>
    <text x="60" y="706" font-family="{FONT}" font-size="14" fill="{MUTED}">{esc(slide["section"])}</text>
    <text x="640" y="706" font-family="{FONT}" font-size="12" fill="{MUTED}" text-anchor="middle">Source: Draft.docx / Draft.md; PlanBridgeSlides branch plan</text>
    <rect x="1210" y="688" width="30" height="24" fill="{PRIMARY}"/>
    <text x="1225" y="706" font-family="Arial, sans-serif" font-size="14" font-weight="bold" fill="#FFFFFF" text-anchor="middle">{num:02d}</text>
  </g>"""


def card(x, y, w, h, title, body, icon=None, fill=WHITE):
    icon_svg = f'<use data-icon="{icon}" x="{x+22}" y="{y+24}" width="34" height="34" fill="{PRIMARY}"/>' if icon else ""
    tx = x + (72 if icon else 24)
    return f"""
  <g id="card-{esc(title)}">
    <rect x="{x}" y="{y}" width="{w}" height="{h}" rx="10" fill="{fill}" stroke="{BORDER}" filter="url(#shadow)"/>
    {icon_svg}
    {tspans(title, tx, y+48, 20, TEXT, "bold", 16)}
    {tspans(body, x+24, y+92, 15, MUTED, "normal", max(16, int((w-48)/15)))}
  </g>"""


def flow_nodes(items, y=335):
    parts = []
    n = len(items)
    gap = 18
    w = int((1120 - gap*(n-1)) / n)
    x0 = 80
    for i, item in enumerate(items):
        x = x0 + i*(w+gap)
        parts.append(f'<g id="step-{i+1}"><rect x="{x}" y="{y}" width="{w}" height="116" rx="10" fill="{WHITE}" stroke="{BORDER}" filter="url(#shadow)"/>')
        parts.append(f'<circle cx="{x+34}" cy="{y+34}" r="18" fill="{PRIMARY}"/><text x="{x+34}" y="{y+41}" font-family="Arial" font-size="18" font-weight="bold" fill="#FFFFFF" text-anchor="middle">{i+1}</text>')
        parts.append(tspans(item, x+24, y+82, 17, TEXT, "bold", 10, anchor="start"))
        parts.append('</g>')
        if i < n-1:
            parts.append(f'<line x1="{x+w+4}" y1="{y+58}" x2="{x+w+gap-6}" y2="{y+58}" stroke="{PRIMARY}" stroke-width="3" marker-end="url(#arrowHead)"/>')
    return "\n".join(parts)


def build_content(slide, num):
    k = slide["kind"]
    b = slide["bullets"]
    if k == "cover":
        return f"""
  <image href="../images/tech_cover.png" x="0" y="0" width="1280" height="720" preserveAspectRatio="xMidYMid slice"/>
  <rect x="0" y="0" width="1280" height="720" fill="{BG}" fill-opacity="0.32"/>
  <rect x="0" y="0" width="1280" height="8" fill="{ACCENT}"/>
  <rect x="0" y="0" width="58" height="720" fill="{PRIMARY}" fill-opacity="0.92"/>
  <rect x="58" y="280" width="1222" height="78" fill="{WHITE}" fill-opacity="0.78"/>
  <text x="640" y="220" font-family="{FONT}" font-size="54" font-weight="bold" fill="{TEXT}" text-anchor="middle">{esc(slide["title"])}</text>
  <text x="640" y="330" font-family="{FONT}" font-size="24" fill="{TEXT}" text-anchor="middle">{esc(slide["takeaway"])}</text>
  <g id="keywords">
    {''.join([f'<rect x="{230+i*170}" y="420" width="138" height="42" rx="8" fill="{PRIMARY if i%2==0 else SECONDARY}"/><text x="{299+i*170}" y="447" font-family="{FONT}" font-size="16" font-weight="bold" fill="#FFFFFF" text-anchor="middle">{esc(txt)}</text>' for i, txt in enumerate(b)])}
  </g>
  <text x="640" y="590" font-family="{FONT}" font-size="18" fill="{MUTED}" text-anchor="middle">基于 Draft.docx 的技术方案汇报</text>"""
    if k == "tradeoff":
        return "\n".join([
            '<g id="tradeoff-triangle">',
            f'<polygon points="640,190 245,570 1035,570" fill="{WHITE}" stroke="{BORDER}" stroke-width="2" filter="url(#shadow)"/>',
            f'<circle cx="640" cy="250" r="58" fill="{PRIMARY}"/><text x="640" y="258" font-family="{FONT}" font-size="18" font-weight="bold" fill="#FFFFFF" text-anchor="middle">稳定输出</text>',
            f'<circle cx="345" cy="535" r="58" fill="{SECONDARY}"/><text x="345" y="543" font-family="{FONT}" font-size="18" font-weight="bold" fill="#FFFFFF" text-anchor="middle">轻量部署</text>',
            f'<circle cx="935" cy="535" r="58" fill="{ACCENT}"/><text x="935" y="543" font-family="{FONT}" font-size="18" font-weight="bold" fill="#FFFFFF" text-anchor="middle">可编辑交付</text>',
            card(455, 365, 370, 120, "核心判断", "生成系统的目标应是可控草稿生产，而不是不可检查的黑盒成品。", "chunk/target"),
            "</g>",
        ])
    if k == "matrix":
        names = [("HTML 直接输出", "分享轻量、交互强；不是原生 PPTX"), ("非编辑型 PPTX", "导出容易；对象常固化为截图"), ("HTML-to-PPTX", "兼顾网页生成；依赖映射质量"), ("SVG-to-PPTX", "结构清晰、可控性强；适合原生交付")]
        cells = []
        for i, (t, d) in enumerate(names):
            x = 90 + (i % 2) * 560
            y = 190 + (i // 2) * 205
            cells.append(card(x, y, 500, 150, t, d, ["chunk/code", "chunk/file", "chunk/git-branch", "chunk/layers"][i]))
        return "\n".join(cells)
    if k == "converge":
        return f"""
  <image href="../images/tech_network.png" x="730" y="150" width="460" height="440" preserveAspectRatio="xMidYMid slice"/>
  <rect x="730" y="150" width="460" height="440" fill="{BG}" fill-opacity="0.22"/>
  {card(90, 210, 300, 130, "HTML 分支", "模板丰富、静态部署、演示交互、快速分享。", "chunk/code")}
  {card(90, 430, 300, 130, "PPTX 分支", "结构化中间态、后处理可控、原生可编辑。", "chunk/file")}
  <line x1="390" y1="275" x2="548" y2="340" stroke="{PRIMARY}" stroke-width="3" marker-end="url(#arrowHead)"/>
  <line x1="390" y1="495" x2="548" y2="420" stroke="{PRIMARY}" stroke-width="3" marker-end="url(#arrowHead)"/>
  {card(548, 315, 260, 130, "统一策划层", "主题、受众、叙事、页型、素材和讲稿强度。", "chunk/folder-open")}"""
    if k == "folders":
        return "\n".join([card(80+i*300, 240, 250, 210, b[i], ["源材料与 slides_plan.md", "HTML 分支副本与运行资源", "PPTX 确认、设计规格与生成产物", "只放校验通过的最终交付物"][i], ["chunk/folder-open","chunk/code","chunk/file","chunk/checkmark"][i]) for i in range(4)])
    if k == "flow":
        return flow_nodes(b, 310)
    if k == "branch":
        left = flow_nodes(b, 315) if len(b) <= 5 else flow_nodes(b[:5], 315)
        return left
    if k == "pillars":
        bodies = ["页面类型、组件结构、样式变量和资产路径。", "减少自由布局导致的文本溢出、组件遮挡和风格漂移。", "模板可扩展，分支仍可决定配色、字体、图标和图片。"]
        return "\n".join([card(105+i*390, 250, 330, 230, b[i], bodies[i], ["chunk/layout","chunk/shield-check","chunk/sparkles"][i]) for i in range(3)])
    if k == "gates":
        return flow_nodes(b, 305)
    if k == "metrics":
        parts = []
        for i, item in enumerate(b):
            x = 80 + (i % 4) * 290
            y = 180 + (i // 4) * 150
            parts.append(card(x, y, 250, 105, item, "可检查指标", ["chunk/checkmark","chunk/layers","chunk/file","chunk/bolt","chunk/chart-line","chunk/folder","chunk/database"][i]))
        return "\n".join(parts)
    if k == "ending":
        return f"""
  <image href="../images/tech_ending.png" x="0" y="0" width="1280" height="720" preserveAspectRatio="xMidYMid slice"/>
  <rect x="0" y="0" width="1280" height="720" fill="{BG}" fill-opacity="0.48"/>
  <rect x="0" y="0" width="58" height="720" fill="{PRIMARY}" fill-opacity="0.90"/>
  <text x="120" y="180" font-family="{FONT}" font-size="38" font-weight="bold" fill="{TEXT}">未来是受控生成、草稿编辑与模板资产库协作</text>
  {card(120, 270, 320, 170, "可控", "统一策划保证内容一致性。", "chunk/target")}
  {card(480, 270, 320, 170, "可查", "中间态让失败更早暴露。", "chunk/checkmark")}
  {card(840, 270, 320, 170, "可改", "PPTX 保留离线编辑空间。", "chunk/file")}
  <text x="640" y="585" font-family="{FONT}" font-size="24" font-weight="bold" fill="{PRIMARY}" text-anchor="middle">PlanBridgeSlides skill</text>"""
    return ""


def svg(slide, num):
    if slide["kind"] in ("cover", "ending"):
        body = build_content(slide, num)
        return f'<svg width="{W}" height="{H}" viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg">\n{defs()}\n{body}\n</svg>\n'
    body = build_content(slide, num)
    return f'<svg width="{W}" height="{H}" viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg">\n{defs()}\n<rect x="0" y="0" width="{W}" height="{H}" fill="{BG}"/>\n{header(slide, num)}\n{body}\n{footer(slide, num)}\n</svg>\n'


def write_design_spec():
    spec = f"""# PlanBridgeSlides skill - Design Spec

## I. Project Information

| Item | Value |
| ---- | ----- |
| **Project Name** | planbridgeslides-skill-grgppt-v2-20260430-pptx |
| **Canvas Format** | PPT 16:9 (1280x720) |
| **Page Count** | 12 |
| **Design Style** | General Consulting with ai_ops template foundation |
| **Target Audience** | 技术评审者、研究团队、LLM Agent Skills / 自动化 PPT 生成相关技能开发者 |
| **Use Case** | 技术方案汇报、项目评审、内部分享 |
| **Created Date** | 2026-05-07 |

## II. Canvas Specification

| Property | Value |
| -------- | ----- |
| **Format** | ppt169 |
| **Dimensions** | 1280x720 |
| **viewBox** | `0 0 1280 720` |
| **Margins** | left/right 50px, top 80px, bottom 40px |
| **Content Area** | 1180x520, approximately x=50, y=150 |

## III. Visual Theme

- **Style**: General Consulting
- **Theme**: Light Morandi technology theme, based on ai_ops structure
- **Tone**: structured, technical, restrained, modular, inspection-friendly

| Role | HEX | Purpose |
| ---- | --- | ------- |
| **Background** | `{BG}` | Page background |
| **Secondary bg** | `{BG2}` | Footer and section panels |
| **Primary** | `{PRIMARY}` | Titles, connectors, icons |
| **Accent** | `{ACCENT}` | Top strip and key emphasis |
| **Secondary accent** | `{SECONDARY}` | Branch and support emphasis |
| **Body text** | `{TEXT}` | Main text |
| **Secondary text** | `{MUTED}` | Captions and annotations |
| **Border/divider** | `{BORDER}` | Card borders and dividers |
| **Success** | `{SECONDARY}` | Positive/ready status |
| **Warning** | `{ACCENT}` | Risk and attention markers |

## IV. Typography System

**Recommended preset**: P1

| Role | Chinese | English | Fallback |
| ---- | ------- | ------- | -------- |
| **Title** | Microsoft YaHei | Arial | sans-serif |
| **Body** | Microsoft YaHei | Calibri | Arial |
| **Code** | - | Consolas | Monaco |
| **Emphasis** | SimHei | Arial Black | Microsoft YaHei |

**Font stack**: `'Microsoft YaHei', Arial, sans-serif`

**Baseline**: Body font size = 18px.

| Purpose | Size | Weight |
| ------- | ---- | ------ |
| Cover title | 54px | Bold |
| Content title | 25-32px | Bold |
| Takeaway | 16px | Bold |
| Body content | 15-18px | Regular |
| Annotation | 12-14px | Regular |

## V. Layout Principles

- **Header area**: 80px, follows ai_ops header rhythm with left accent bar.
- **Content area**: x=50-1230, y=150-655; content pages use cards, process flow, matrix, metric tiles.
- **Footer area**: 40px, source attribution and page number.

| Element | Current Project |
| ------- | --------------- |
| Card gap | 18-32px |
| Content block gap | 24-40px |
| Card padding | 22-28px |
| Card border radius | 8-10px |
| Icon-text gap | 12-16px |

## VI. Icon Usage Specification

- **Built-in icon library**: `chunk`
- **Usage method**: `<use data-icon="chunk/name" .../>`
- **Rule**: one presentation uses only `chunk`.

| Purpose | Icon Path | Page |
| ------- | --------- | ---- |
| Code / HTML | `chunk/code` | 03, 04, 07 |
| File / PPTX | `chunk/file` | 03, 08, 12 |
| Folder / workspace | `chunk/folder-open` | 04, 05 |
| Check / quality gate | `chunk/checkmark` | 05, 10, 12 |
| Target / objective | `chunk/target` | 02, 12 |
| Shield / safety | `chunk/shield-check` | 09 |
| Data / metrics | `chunk/chart-line`, `chunk/chart-bar` | 11 |
| Spark / technology | `chunk/sparkles` | 09 |

## VII. Visualization Reference List

| Visualization Type | Reference Template | Used In |
| ------------------ | ------------------ | ------- |
| matrix_2x2 | `templates/charts/matrix_2x2.svg` | Slide 03 |
| process_flow | `templates/charts/process_flow.svg` | Slides 06, 07, 08, 10 |
| hub_spoke | `templates/charts/hub_spoke.svg` | Slide 04 |
| icon_grid | `templates/charts/icon_grid.svg` | Slide 11 |
| numbered_steps | `templates/charts/numbered_steps.svg` | Slide 05 |

## VIII. Image Resource List

| Filename | Dimensions | Ratio | Purpose | Type | Status | Generation Description |
| -------- | ---------- | ----- | ------- | ---- | ------ | ---------------------- |
| tech_cover.png | 1280x720 | 1.78 | Cover background | Background | AI-generated | Morandi low-saturation technology network, abstract digital paths converging into a planning layer, clean center for title |
| tech_network.png | 1280x720 | 1.78 | Architecture accent image | Background | AI-generated | Abstract nodes, flowing digital waves, muted blue-gray and sage palette, no text |
| tech_ending.png | 1280x720 | 1.78 | Closing background | Background | AI-generated | Calm futuristic knowledge network, warm Morandi palette, subtle particles, no text |

## IX. Content Outline
"""
    for i, s in enumerate(slides, 1):
        spec += f"""
### Slide {i:02d} - {s['title']}

- **Layout**: {s['kind']}
- **Title**: {s['title']}
- **Takeaway**: {s['takeaway']}
- **Visualization**: {'process_flow' if s['kind'] in ['flow','branch','gates'] else 'matrix_2x2' if s['kind']=='matrix' else 'icon_grid' if s['kind']=='metrics' else 'custom layout'}
- **Content**:
"""
        for bullet in s["bullets"]:
            spec += f"  - {bullet}\n"
    spec += """
## X. Speaker Notes Requirements

Generate Chinese speaker notes. `notes/total.md` uses `#` headings and `---` separators; split note files must not contain heading lines. Notes are conclusion-first, concise, and suitable for a 12-15 minute technical report.

## XI. Technical Constraints Reminder

1. viewBox: `0 0 1280 720`
2. Background uses `<rect>`.
3. Text wrapping uses `<tspan>`; `<foreignObject>` is forbidden.
4. Transparency uses `fill-opacity` / `stroke-opacity`; `rgba()` is forbidden.
5. Forbidden: `mask`, `<style>`, `class`, `foreignObject`, `textPath`, animation, script.
6. Use `finalize_svg.py` before `svg_to_pptx.py -s final`.
"""
    (ROOT / "design_spec.md").write_text(spec, encoding="utf-8")


def write_notes():
    parts = []
    for i, s in enumerate(slides, 1):
        parts.append(f"# {Path(s['file']).stem}\n")
        prefix = "" if i == 1 else "[过渡] "
        parts.append(f"{prefix}{s['note']}\n\n")
        parts.append(f"要点：① {s['takeaway']} ② 关注 {s['section']} ③ 与下一页形成逻辑递进\n")
        parts.append("时长：1 分钟\n")
        parts.append("---\n")
    (NOTES_DIR / "total.md").write_text("\n".join(parts), encoding="utf-8")


def main():
    ensure_dirs()
    make_tech_image("tech_cover.png", 11)
    make_tech_image("tech_network.png", 22)
    make_tech_image("tech_ending.png", 33)
    write_design_spec()
    for i, s in enumerate(slides, 1):
        (SVG_DIR / s["file"]).write_text(svg(s, i), encoding="utf-8")
    write_notes()
    print(f"Generated {len(slides)} SVG files, design_spec.md, notes/total.md and 3 image assets.")


if __name__ == "__main__":
    main()
