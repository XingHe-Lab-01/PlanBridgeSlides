# PlanBridgeSlides skill - Design Spec

## I. Project Information

| Item | Value |
| ---- | ----- |
| **Project Name** | planbridgeslides-skill-grgppt-v2-20260430-pptx |
| **Canvas Format** | PPT 16:9 (1280x720) |
| **Page Count** | 12 |
| **Design Style** | General Consulting with ai_ops template foundation |
| **Target Audience** | 技术评审者、研究团队、LLM Agent Skills / 自动化 PPT 生成相关技能开发者 |
| **Use Case** | 技术方案汇报、项目评审、内部分享 |
| **Created Date** | 2026-05-07 |

## II. Canvas Specification

| Property | Value |
| -------- | ----- |
| **Format** | ppt169 |
| **Dimensions** | 1280x720 |
| **viewBox** | `0 0 1280 720` |
| **Margins** | left/right 50px, top 80px, bottom 40px |
| **Content Area** | 1180x520, approximately x=50, y=150 |

## III. Visual Theme

- **Style**: General Consulting
- **Theme**: Light Morandi technology theme, based on ai_ops structure
- **Tone**: structured, technical, restrained, modular, inspection-friendly

| Role | HEX | Purpose |
| ---- | --- | ------- |
| **Background** | `#F4F1EC` | Page background |
| **Secondary bg** | `#E7E2DA` | Footer and section panels |
| **Primary** | `#6F8796` | Titles, connectors, icons |
| **Accent** | `#C08F80` | Top strip and key emphasis |
| **Secondary accent** | `#9AAE9A` | Branch and support emphasis |
| **Body text** | `#2F3437` | Main text |
| **Secondary text** | `#6C7478` | Captions and annotations |
| **Border/divider** | `#D8D1C8` | Card borders and dividers |
| **Success** | `#9AAE9A` | Positive/ready status |
| **Warning** | `#C08F80` | Risk and attention markers |

## IV. Typography System

**Recommended preset**: P1

| Role | Chinese | English | Fallback |
| ---- | ------- | ------- | -------- |
| **Title** | Microsoft YaHei | Arial | sans-serif |
| **Body** | Microsoft YaHei | Calibri | Arial |
| **Code** | - | Consolas | Monaco |
| **Emphasis** | SimHei | Arial Black | Microsoft YaHei |

**Font stack**: `'Microsoft YaHei', Arial, sans-serif`

**Baseline**: Body font size = 18px.

| Purpose | Size | Weight |
| ------- | ---- | ------ |
| Cover title | 54px | Bold |
| Content title | 25-32px | Bold |
| Takeaway | 16px | Bold |
| Body content | 15-18px | Regular |
| Annotation | 12-14px | Regular |

## V. Layout Principles

- **Header area**: 80px, follows ai_ops header rhythm with left accent bar.
- **Content area**: x=50-1230, y=150-655; content pages use cards, process flow, matrix, metric tiles.
- **Footer area**: 40px, source attribution and page number.

| Element | Current Project |
| ------- | --------------- |
| Card gap | 18-32px |
| Content block gap | 24-40px |
| Card padding | 22-28px |
| Card border radius | 8-10px |
| Icon-text gap | 12-16px |

## VI. Icon Usage Specification

- **Built-in icon library**: `chunk`
- **Usage method**: `<use data-icon="chunk/name" .../>`
- **Rule**: one presentation uses only `chunk`.

| Purpose | Icon Path | Page |
| ------- | --------- | ---- |
| Code / HTML | `chunk/code` | 03, 04, 07 |
| File / PPTX | `chunk/file` | 03, 08, 12 |
| Folder / workspace | `chunk/folder-open` | 04, 05 |
| Check / quality gate | `chunk/checkmark` | 05, 10, 12 |
| Target / objective | `chunk/target` | 02, 12 |
| Shield / safety | `chunk/shield-check` | 09 |
| Data / metrics | `chunk/chart-line`, `chunk/chart-bar` | 11 |
| Spark / technology | `chunk/sparkles` | 09 |

## VII. Visualization Reference List

| Visualization Type | Reference Template | Used In |
| ------------------ | ------------------ | ------- |
| matrix_2x2 | `templates/charts/matrix_2x2.svg` | Slide 03 |
| process_flow | `templates/charts/process_flow.svg` | Slides 06, 07, 08, 10 |
| hub_spoke | `templates/charts/hub_spoke.svg` | Slide 04 |
| icon_grid | `templates/charts/icon_grid.svg` | Slide 11 |
| numbered_steps | `templates/charts/numbered_steps.svg` | Slide 05 |

## VIII. Image Resource List

| Filename | Dimensions | Ratio | Purpose | Type | Status | Generation Description |
| -------- | ---------- | ----- | ------- | ---- | ------ | ---------------------- |
| tech_cover.png | 1280x720 | 1.78 | Cover background | Background | AI-generated | Morandi low-saturation technology network, abstract digital paths converging into a planning layer, clean center for title |
| tech_network.png | 1280x720 | 1.78 | Architecture accent image | Background | AI-generated | Abstract nodes, flowing digital waves, muted blue-gray and sage palette, no text |
| tech_ending.png | 1280x720 | 1.78 | Closing background | Background | AI-generated | Calm futuristic knowledge network, warm Morandi palette, subtle particles, no text |

## IX. Content Outline

### Slide 01 - PlanBridgeSlides skill

- **Layout**: cover
- **Title**: PlanBridgeSlides skill
- **Takeaway**: 模板约束与清晰中间态的高可用幻灯片生成方法
- **Visualization**: custom layout
- **Content**:
  - Agent Skills
  - 自动化 PPT
  - 统一策划
  - 分支交付
  - 可编辑草稿

### Slide 02 - 高质量 PPT 生成不是一键生成，而是可控草稿生产

- **Layout**: tradeoff
- **Title**: 高质量 PPT 生成不是一键生成，而是可控草稿生产
- **Takeaway**: 普通用户真正需要的是低成本、高质量、可继续编辑的演示草稿。
- **Visualization**: custom layout
- **Content**:
  - 组织材料
  - 结构化内容
  - 排版表达
  - 反复修改

### Slide 03 - 主流 PPT 生成路线分成四类，各有适用边界

- **Layout**: matrix
- **Title**: 主流 PPT 生成路线分成四类，各有适用边界
- **Takeaway**: 没有绝对最优路线，关键是根据交付需求选择中间表示和输出格式。
- **Visualization**: matrix_2x2
- **Content**:
  - HTML 直接输出
  - 非编辑型 PPTX
  - HTML-to-PPTX
  - SVG-to-PPTX

### Slide 04 - PlanBridgeSlides skill 的目标是统一策划，分支交付

- **Layout**: converge
- **Title**: PlanBridgeSlides skill 的目标是统一策划，分支交付
- **Takeaway**: 先稳定内容事实和页面结构，再让 HTML 与 PPTX 分支各自发挥格式优势。
- **Visualization**: custom layout
- **Content**:
  - HTML：分享与交互
  - PPTX：离线编辑
  - planning：内容真相源

### Slide 05 - 四个顶层目录定义生成过程的可检查边界

- **Layout**: folders
- **Title**: 四个顶层目录定义生成过程的可检查边界
- **Takeaway**: 目录结构把内容规划、分支设计、生成和交付都暴露为可检查中间态。
- **Visualization**: custom layout
- **Content**:
  - planning/
  - html/
  - pptx/
  - output/

### Slide 06 - 先把“讲什么”固定，再讨论“做成什么”

- **Layout**: flow
- **Title**: 先把“讲什么”固定，再讨论“做成什么”
- **Takeaway**: 共享策划层把异构输入整理为两条分支都能复用的内容规划。
- **Visualization**: process_flow
- **Content**:
  - 源材料归档
  - 内容标准化
  - slides_plan.md
  - 可用性自检
  - 分支选择

### Slide 07 - HTML 分支面向轻量分享和交互演示

- **Layout**: branch
- **Title**: HTML 分支面向轻量分享和交互演示
- **Takeaway**: HTML 交付适合快速打开、分享和演示，并保留 presenter mode 等运行能力。
- **Visualization**: process_flow
- **Content**:
  - theme / layout
  - runtime
  - presenter notes
  - standalone HTML

### Slide 08 - PPTX 分支把共享规划转为可编辑的原生 PowerPoint

- **Layout**: branch
- **Title**: PPTX 分支把共享规划转为可编辑的原生 PowerPoint
- **Takeaway**: PPTX 分支更强调结构化生成、后处理控制和可编辑对象。
- **Visualization**: process_flow
- **Content**:
  - 模板确认
  - Eight Confirmations
  - design_spec.md
  - SVG 后处理
  - 文本安全检查

### Slide 09 - 模板不是限制创造力，而是给模型可控边界

- **Layout**: pillars
- **Title**: 模板不是限制创造力，而是给模型可控边界
- **Takeaway**: 模板库把页面结构和视觉表达限制在可验证范围内，减少自由布局漂移。
- **Visualization**: custom layout
- **Content**:
  - 约束对象
  - 降低风险
  - 保留弹性

### Slide 10 - 每个中间产物都是一次可检查的质量门

- **Layout**: gates
- **Title**: 每个中间产物都是一次可检查的质量门
- **Takeaway**: 内容规划、分支设计、页面生成、后处理和最终交付被分层暴露。
- **Visualization**: process_flow
- **Content**:
  - 内容层
  - 分支层
  - 生成层
  - 后处理层
  - 交付层

### Slide 11 - 高可用不只看美观，还要看编辑、稳定和成本

- **Layout**: metrics
- **Title**: 高可用不只看美观，还要看编辑、稳定和成本
- **Takeaway**: 评价体系把主观视觉质量拆成可检查的工程指标。
- **Visualization**: icon_grid
- **Content**:
  - 文本溢出
  - 组件遮挡
  - 可编辑性
  - 部署成本
  - 输出稳定性
  - 模板库容量
  - 输入支持能力

### Slide 12 - 未来是受控生成、草稿编辑与模板资产库协作

- **Layout**: ending
- **Title**: 未来是受控生成、草稿编辑与模板资产库协作
- **Takeaway**: PPT 生成技能的长期价值在于沉淀组织知识和沟通标准。
- **Visualization**: custom layout
- **Content**:
  - 统一策划保证内容一致
  - 分支执行保留格式优势
  - 模板资产库沉淀组织标准

## X. Speaker Notes Requirements

Generate Chinese speaker notes. `notes/total.md` uses `#` headings and `---` separators; split note files must not contain heading lines. Notes are conclusion-first, concise, and suitable for a 12-15 minute technical report.

## XI. Technical Constraints Reminder

1. viewBox: `0 0 1280 720`
2. Background uses `<rect>`.
3. Text wrapping uses `<tspan>`; `<foreignObject>` is forbidden.
4. Transparency uses `fill-opacity` / `stroke-opacity`; `rgba()` is forbidden.
5. Forbidden: `mask`, `<style>`, `class`, `foreignObject`, `textPath`, animation, script.
6. Use `finalize_svg.py` before `svg_to_pptx.py -s final`.
