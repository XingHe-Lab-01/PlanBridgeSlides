# planbridgeslides-skill-grgppt-v2-20260430-pptx

- Canvas format: ppt169
- Created: 20260507

## Directories

- `svg_output/`: raw SVG output
- `svg_final/`: finalized SVG output
- `images/`: presentation assets
- `notes/`: speaker notes
- `templates/`: project templates
- `sources/`: source materials and normalized markdown
- `exports/`: generated PPTX files (timestamped history)
